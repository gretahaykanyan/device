<?php
namespace model;

class Students
{

    function change(array $arr)
    {
        header("Content-type: application/json; charset=utf-8");
        $conn = $this->connect();

        $arr = $this->mysql_fix_string($arr, $conn);
        $data = array(
            'error' => "",
            'success' => "",
            'img' => "",
            'uname' => "",
            "passerror" => '',
        );
        $query = $conn->prepare("SELECT * FROM `students` WHERE `Id`=?");
        $query->bind_param("i", $arr['id']);
        $query->execute();
        $result = $query->get_result();
        $fetch = $result->fetch_assoc();
        $salt1 = "qm&h*";
        $salt2 = "pg!@";
        $cpass = $arr['cpassword'];
        $pass = $arr['password'];

        $arr['cpassword'] = hash('ripemd128', "$salt1$cpass$salt2");
        if ((($pass == "") && ($cpass == "")) || (($pass == "") || ($cpass == ""))) {
            $arr['password'] = $fetch['password'];


        } else if ($fetch['password'] == $arr['cpassword']) {

            $arr['password'] = hash('ripemd128', "$salt1$pass$salt2");

        } else {
            $arr['password'] = "";
            $data['passerror'] = "Հին գաղտնաբառը չի համապատասխանում";
        }
        $data["img"] = $fetch['Img'];
        $code = 0;
        if ($arr['password'] !== "") {

            if (file_exists($_FILES['image']['tmp_name']) || is_uploaded_file($_FILES['image']['tmp_name'])) {
                $this->image_remove($fetch['Img']);
                $imgpath = $this->image_upload($_FILES['image']);

                $stmt = $conn->prepare("UPDATE `students` SET `Name`= ?,`Sname`=?,`Bday`=?,`Gender`=?,`Img`=?,`userName`=?,`password`=?,`email`=?,`code`=?
                            WHERE `Id`=?");
                $stmt->bind_param("ssssssssii", $arr['Name'], $arr['Sname'], $arr['Bday'], $arr['Gender'], $imgpath, $arr['userName'], $arr['password'], $arr['email'], $code, $arr["id"]);

                $data["img"] = $imgpath;
                $data['uname'] = $_SESSION["uname"] = $arr['userName'];
            } else {
                $stmt = $conn->prepare("UPDATE `students` SET `Name`= ?,`Sname`=?,`Bday`=?,`Gender`=?,`userName`=?,`password`=?,`email`=?,`code`=?
                            WHERE `Id`=?");
                $stmt->bind_param("sssssssii", $arr['Name'], $arr['Sname'], $arr['Bday'], $arr['Gender'], $arr['userName'], $arr['password'], $arr['email'], $code, $arr["id"]);
                $data['uname'] = $_SESSION["uname"] = $arr['userName'];
            }

            if ($stmt->execute()) {
                $data["success"] = ' տվյալները փոխվեցին';
            } else {
                $data["error"] = 'Չհաջողվեց փոփոխել';
            }
        }

        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function courses($id)
    {
        $conn = $this->connect();
        $data = array(
            "fetchCourses" => [],
            "fetchSelected" => [],
            "price" => [],
            "count" => "",
        );
        $query = "SELECT * FROM `courses` WHERE `deleted`=0";
        $result = $conn->query($query);

        while ($row = $result->fetch_assoc()) {
            array_unshift($data['fetchCourses'], $row);
        }
        $data['fetchSelected'] = $this->selectedCourses($id);
        $data["price"] = $this->totalPrice($id);
        $data["count"] = count($data['fetchSelected']);
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));

    }
    function getUserInfo($uname)
    {
        $conn = $this->connect();
        $fetch = [];
        $query = $conn->prepare("SELECT * FROM `students` WHERE `userName` =?");
        $query->bind_param("s", $uname);
        $query->execute();
        $result = $query->get_result();

        while ($row = $result->fetch_assoc()) {
            array_unshift($fetch, $row);
        }

        echo (json_encode($fetch, JSON_UNESCAPED_UNICODE));
    }
    function addCourses($coursId, $studentId)
    {
        $conn = $this->connect();
        $data = array(
            'error' => "",
            'success' => "",
            'fetchSelected' => [],
            "price" => [],
            "count" => "",
        );
        $query = $conn->prepare("SELECT * FROM `selected` WHERE `coursesId`=? AND `studentsId`=? ");
        $query->bind_param("ii", $coursId, $studentId);
        $query->execute();
        $result = $query->get_result();
        $fetch = $result->fetch_assoc();
        if ($result->num_rows > 0) {
            $query = $conn->prepare("UPDATE `selected` SET `deleted` = '0' WHERE `selected`.`coursesId` = ? AND `selected`.`studentsId` = ?;");
            $query->bind_param("ii", $coursId, $studentId);
            if ($query->execute()) {
                $data['success'] = "add";
            } else {
                $data['error'] = "error";
            }

        } else {
            $query = $conn->prepare("INSERT INTO `selected` (`coursesId`,`studentsId`) VALUES (?,?)");
            $query->bind_param("ii", $coursId, $studentId);
            if ($query->execute()) {
                $data['success'] = "add";
            } else {
                $data['error'] = "error";
            }

        }
        $data['fetchSelected'] = $this->selectedCourses($studentId);
        $data["price"] = $this->totalPrice($studentId);
        $data["count"] = count($data['fetchSelected']);
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function selectedCourses($studentId)
    {
        $conn = $this->connect();
        $fetch = [];
        $query = $conn->prepare("SELECT courses.coursName, courses.level , courses.Img, courses.price, courses.duration, courses.countClass,  courses.Id as coursesId 
                    FROM selected 
                    JOIN courses ON selected.coursesId = courses.Id 
                    JOIN students ON selected.studentsId = students.Id 
                    WHERE students.Id = ? AND  selected.deleted = '0' ");

        $query->bind_param("i", $studentId);
        $query->execute();
        $result = $query->get_result();

        while ($row = $result->fetch_assoc()) {
            array_unshift($fetch, $row);
        }
        //$fetch["count"]= $result->num_rows;

        return $fetch;
    }
    function totalPrice($id)
    {
        $conn = $this->connect();

        $query = $conn->prepare("SELECT SUM(courses.price * courses.duration) AS totalPrice,  
                 SUM(courses.price * courses.duration) * 
                    IF(SUM(courses.price * courses.duration) > 150000,
                        IF(SUM(courses.price * courses.duration) > 200000,
                            IF(SUM(courses.price * courses.duration) > 500000,
                            .65,
                        .75),
                    .85),
                    0) AS DiscountPrice 
                FROM selected 
                    JOIN courses ON selected.coursesId = courses.Id 
                    JOIN students ON selected.studentsId = students.Id 
                WHERE students.Id = ? AND  selected.deleted = '0';");
        $query->bind_param("i", $id);
        $query->execute();

        $result = $query->get_result();

        $fetch = $result->fetch_assoc();

        return $fetch;
    }
    function delete($studentId, $coursId)
    {
        $conn = $this->connect();

        $data = array(
            'error' => "",
            'success' => "",
            "price" => [],
            "count" => "",
        );

        $stmt = $conn->prepare("UPDATE `selected` SET `deleted`='1' WHERE `studentsId`=? AND `coursesId`=?");
        $stmt->bind_param("ii", $studentId, $coursId);

        if ($stmt->execute()) {
            $data["success"] = 'ջնջված է';
        } else {
            $data["error"] = 'Չհաջողվեց ջնջել ';
        }
        $data["price"] = $this->totalPrice($studentId);
        $data["count"] = count($this->selectedCourses($studentId));
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function deleteAll($Id)
    {

        $conn = $this->connect();
        $data = array(
            'error' => "",
            'success' => "",
            "price" => [],
            "count" => "0",
        );

        $stmt = $conn->prepare("UPDATE `selected` SET `deleted`='1' WHERE `studentsId`=? ");
        $stmt->bind_param("i", $Id);

        if ($stmt->execute()) {
            $data["success"] = 'ջնջված է';
        } else {
            $data["error"] = 'Չհաջողվեց ջնջել ';
        }
        $data["price"] = $this->totalPrice($Id);
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    public function connect()
    {
        $DB = new \Database();
        $conn = $DB->connectDB();
        $conn->set_charset("utf8");
        return $conn;
    }
    public function mysql_fix_string(array $metod, $conn)
    {
        foreach ($metod as $key => $value) {
            $metod[$key] = htmlentities($conn->real_escape_string($value));
        }
        return $metod;
    }
    function image_upload($img)
    {
        $tmp_loc = $img['tmp_name'];

        $new_name = random_int(11111, 99999) . $img['name'];
        $new_loc = $_SERVER['DOCUMENT_ROOT'] . "/public/uploads/" . $new_name;
        if (!move_uploaded_file($tmp_loc, $new_loc)) {
            $_SESSION['delete'] = 'Չհաջողվեց փոխել նկարը ';

        } else {
            return $new_name;
        }
    }
    function image_remove($img)
    {
        if (!unlink($_SERVER['DOCUMENT_ROOT'] . "/public/uploads/" . $img)) {
            $_SESSION['delete'] = 'Չհաջողվեց ջնջել նկարը';

        }
    }

}
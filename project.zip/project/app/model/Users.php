<?php

namespace model;

class Users
{

    public function signUp(array $post)
    {
        $conn = $this->connect();
        $post = $this-> mysql_fix_string($post,$conn);
        if (filter_var($post['email'], FILTER_VALIDATE_EMAIL)) {

            $stmt = $conn->prepare("SELECT * FROM students WHERE userName =? OR email =?");
            $stmt->bind_param("ss", $post['userName'],$post['email']);
            $stmt->execute();
            $result =$stmt->get_result();
            $arr = array(
                'error' => "", 'success' => "", 'ok' => false,
            );

            if ($result->num_rows > 0) {

                $arr["error"] = 'Մուտքանունը կամ Էլ. հասցեն արդեն գրանցված է';
            } else {
                $pass = $post['password'];
                $salt1 = "qm&h*";
                $salt2 = "pg!@";
                $password = hash('ripemd128', "$salt1$pass$salt2");
                $code = rand(999999, 111111);
                $imgpath = $this->image_upload($_FILES['image']);


                $insert = $conn->prepare("INSERT INTO `students`(`Name`, `Sname`, `Bday`,`Gender`,`Img`,`userName`, `email`, `password`, `code`) VALUES (?,?,?,?,?,?,?,?,?)");
                $insert->bind_param("ssssssssi", $post['Name'],$post['Sname'],$post['Bday'],$post['Gender'],$imgpath,$post['userName'],$post['email'],$password, $code );
              
                
                if ($insert->execute()) {
                    $subject = "Էլ. հասցեի հաստատման հղում ";
                    $body = "Ձեր Էլ. հասցեի հաստատման հղումն է <a href='http://project.loc/public/users/signin?email={$post['email']}&code=$code'>հաստատել</a>";
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    $headers .= 'MAIL FROM <greatagreata146@gmail.com>' .  "\r\n ";

                    if (mail($post['email'], $subject, $body, $headers)) {
                        $arr["success"]  = 'Հաստատման հղումը ուղարկվել է՝ ' . $post['email'] . ' էլ. հասցեին';
                    } else {
                        $arr["error"] = 'Ձախողվեց ուղարկել հաստատման հղումը';
                    }
                } else {
                    $arr["error"] = 'Ձախողվեց գրանցվել';
                }
            }
        } else {
            $arr["error"] = 'Ներմուծել ճիշտ էլ․ հասցե';
        }
        echo (json_encode($arr,JSON_UNESCAPED_UNICODE));
    }

    public function signIn(array $post)
    {

        $conn = $this->connect();
        $arr = $this-> mysql_fix_string($_POST,$conn);
        $stmt = $conn->prepare(" SELECT * FROM students WHERE userName =? ");
        $stmt->bind_param("s", $post['userName']);

        $stmt->execute();
        $result =$stmt->get_result();
        $arr = array(
            'error' => "", 'success' => "", 'ok' => false,
        );

        if ($result->num_rows > 0) {
            $pass = $post['password'];
            
            $fetch = $result->fetch_assoc();
            $salt1 = "qm&h*";
            $salt2 = "pg!@";
            $password = hash('ripemd128', "$salt1$pass$salt2");
           
            $fetch_pass = $fetch['password'];
           
            if ($password == $fetch_pass) {

                    $_SESSION['uname'] = $post['userName'];

                    if ($fetch['user'] == '0') {
                        $arr["ok"] = true;
                        $_SESSION['uname']='admin';
                        $arr["success"] = "admin/students";
                    } else {

                        $_SESSION['id'] = $fetch['Id'];
                        $_SESSION['uname'] = $post['userName'];
                        $_SESSION['img'] = $fetch['Img'];
                        $arr["ok"] = true;
                        $arr["success"] = "students";
                    }
            } else {
                $arr["error"] = "Գաղտնաբառը սխալ է";
            }
        } else {
            $arr["error"] = "Այս մուտքանունով օգտատեր գրանցված չէ";
        }
        echo (json_encode($arr,JSON_UNESCAPED_UNICODE));
    }

    public function verified($email, $code)
    {
        var_dump("verifide");
        $DB =  new \Database();
        $conn = $DB->connectDB();
        $stmt = $conn->prepare(" SELECT * FROM students WHERE email =? AND code =? ");
        $stmt->bind_param("si", $email,$code);
        
      
        if ( $stmt->execute()) {
         $result =$stmt->get_result();
           
            if ($result->num_rows == 1) {
               
                $fetch = $result->fetch_assoc();

                if ($fetch['status'] == "notverified") {
                    
                    $update = $conn->prepare(" UPDATE students SET code = '0'  ,status ='verified' WHERE  email =? ");
                    $update->bind_param("s", $fetch['email']);
        
                    if ( $update->execute()) {
                        echo "<script>
                        alert('Հաստատված է, կարող եք մուտք գործել');
                        window.location.href = '../users/signin';
                    </script>";
                    }
                }
            }
            echo "<script>
                    alert('Էլ. հասեն արդեն Հաստատված է');
                    window.location.href = '../users/signin';
                  </script>";
        }
    }

    public function forgetPass(array $post)
    {
        $conn = $this->connect();
        $post = $this-> mysql_fix_string($post,$conn);

        $stmt = $conn->prepare(" SELECT * FROM students WHERE  email =? ");
        $stmt->bind_param("s", $post['email']);
        
        $stmt->execute();
        $result =$stmt->get_result();

        $arr = array(
            'error' => "", 'success' => "", 'ok' => false,
        );
        if ($result->num_rows > 0) {
            $code = rand(999999, 111111);
            
            $insert = $conn->prepare("UPDATE students SET code =?  WHERE email = ?");
            $insert->bind_param("is",$code ,$post['email']);
           
            if ($insert->execute()) {
                $subject = "Գաղտնաբառի վերականգնման ծածկագիր ";
                $body = "Ձեր գաղտնաբառի վերականգնման ծածկագիրն է $code";

                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $headers .= 'From: <greatagreata146@gmail.com>' .  "\r\n ";

                if (mail($post['email'], $subject, $body, $headers)) {
                    $_SESSION['info'] = "Ծածկագիրը ուղարկվել է Ձեր ". $post['email']." էլ. հասցեին";
                    $_SESSION['email'] = $post['email'];
                    $arr["ok"] = true;
                    $arr["success"] = "users/reset";
                } else {
                    $arr["error"] = "Սխալ, ծածկագիրը Էլ. հասցեին չի ուղարկվել";
                }
            } else {
                $arr["error"] = "Սխալ";
            }
        } else {
            $arr["error"] = "Էլ. հասցեն սխալ է";
        }
        echo (json_encode($arr,JSON_UNESCAPED_UNICODE));
    }

    public function resetCode($code)
    {
        $conn = $this->connect();
      

        
        $stmt = $conn->prepare(" SELECT * FROM students WHERE  code =? ");
        $stmt->bind_param("i", $code);
        
        $stmt->execute();
        $result =$stmt->get_result();

        $arr = array(
            'error' => "", 'success' => "", 'ok' => false,
        );
        $fetch_data = $result->fetch_assoc();
        
        
        if ($result->num_rows > 0) {

            

            $_SESSION['email'] = $fetch_data['email'];
            $_SESSION['info'] = 'Ստեղծեք նոր գաղտնաբառ որը նախկինում չեք օգտագործել';

            $arr["ok"] = true;
            $arr["success"] = "users/newpass";
        } else {
            $arr['error'] = 'Ներմուծված ծածկագիրը սխալ է';
        }
        echo (json_encode($arr,JSON_UNESCAPED_UNICODE));
    }

    public function changePass(array $post)
    {
        $conn = $this->connect();
        $post = $this-> mysql_fix_string($post,$conn);
        $code = 0;
        $arr = array(
            'error' => "", 'success' => "", 'ok' => false,
        );
        if ($post['password'] !== $post['cpassword']) {
            $arr['error'] = "Գաղտնաբառը չի համապատասխանում";
        } else {
            $password = $post['password'];
            $code = 0;
            $email = $_SESSION['email'];
            $salt1 = "qm&h*";
            $salt2 = "pg!@";
            $password = hash('ripemd128', "$salt1$password$salt2");
          
            $stmt = $conn->prepare("UPDATE students SET code = ?, password = ? WHERE email = ? ");
            $stmt->bind_param("iss", $code,$password,$email);
        
            if ( $stmt->execute()) {
                $_SESSION['info'] = "Ձեր գաղտնաբառը փոխված է";
                $arr["ok"] = true;
                $arr["success"] = "users/signin";
            } else {
                $arr['error'] = "Ձախողվեց գաղտնաբառը փոխել";
            }
        }
        echo (json_encode($arr,JSON_UNESCAPED_UNICODE));
    }

    public function connect()
    {
        $DB =  new \Database();
        $conn = $DB->connectDB();
        $conn->set_charset("utf8");
        return $conn;
    }
    public function mysql_fix_string(array $metod,$conn)
    {
        foreach ($metod as $key => $value) {
            $metod[$key] = htmlentities($conn->real_escape_string($value));
        }
        return $metod;
    }
    function image_upload($img)
    {
        $tmp_loc = $img['tmp_name'];

        $new_name = random_int(11111, 99999) . $img['name'];
        $new_loc = $_SERVER['DOCUMENT_ROOT'] . "/public/uploads/" . $new_name;
        if (!move_uploaded_file($tmp_loc, $new_loc)) {
            $_SESSION['delete'] = 'Չհաջողվեց ավելացնել նկարը ';
           
        } else {
            return $new_name;
        }
    }
}

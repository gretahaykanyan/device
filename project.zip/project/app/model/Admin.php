<?php

namespace model;

class Admin
{
    function addStudent(array $arr, $page, $col, $order)
    {
        $conn = $this->connect();
        $arr = $this->mysql_fix_string($arr, $conn);

        $data = array(
            'emptyErr' => "",
            'error' => "",
            'success' => "",
            'fetchStudents' => [],
            'selectedCourses' => [],
            "countStudentsPage" => "",
        );
        if ($arr['Name'] == "" || $arr['Sname'] == "" || $arr['Gender'] == "") {
            $data['emptyErr'] = "Լրացնել բոլոր դաշտերը";
        }
        if ($data['emptyErr'] == "") {
            $error = $this->validatStudentInfo($arr['Name'], $arr['Sname'], $arr['Gender']);

            if ($error == "") {
                $uname = $this->random_username($conn);
                $pass = $uname;

                $salt1 = "qm&h*";
                $salt2 = "pg!@";
                $password = hash('ripemd128', "$salt1$pass$salt2");

                if ($_FILES['image']['name'] != "") {
                    $imgpath = $this->image_upload($_FILES['image']);
                } else {
                    $imgpath = "img.png";
                }

                $stmt = $conn->prepare("INSERT INTO `students`( `Name`, `Sname`, `Bday`,`Gender`,`Img`,`userName`, `password`) 
                        VALUES (?,?,?,?,?,?,?)");
                $stmt->bind_param("sssssss", $arr['Name'], $arr['Sname'], $arr['Bday'], $arr['Gender'], $imgpath, $uname, $password);

                if ($stmt->execute()) {
                    $data["success"] = ' ավելացվել է ';
                } else {
                    $data["error"] = 'Չհաջողվեց ավելացնել';
                }
            } else {
                $data["error"] = $error;
            }

            $data['fetchStudents'] = $this->getAllStudents($page, $col, $order, "");
            $data['selectedCourses'] = $this->getSelectedCourses();
            $data['countStudentsPage'] = $this->countPage('students', "");
        }
        echo (json_encode($data));
    }
    function addCourses(array $arr, $page, $col, $order)
    {

        $conn = $this->connect();
        $arr = $this->mysql_fix_string($arr, $conn);
        $data = array(
            'emptyErr' => "",
            'error' => "",
            'success' => "",
            'fetchAllCourses' => [],
            'selectedCourses' => [],
            'countCoursesPage' => "",
        );
        if ($arr['coursName'] == "" || $arr['level'] == "" || $arr['image'] == "" || $arr['price'] == "" || $arr['duration'] == "" || $arr['countClass'] == "") {
            $data['emptyErr'] = "Լրացնել բոլոր դաշտերը";
        }
        if ($data['emptyErr'] == "") {
            $error = $this->validatCoursesInfo($arr['coursName'], $arr['level'], $arr['image'], $arr['price'], $arr['duration'], $arr['countClass']);
            if ($error == "") {
                $stmt = $conn->prepare("INSERT INTO `courses`( `coursName`, `level`, `Img`, `price`, `duration`, `countClass`) 
                    VALUES (?,?,?,?,?,?)");
                $stmt->bind_param("sssiis", $arr['coursName'], $arr['level'], $arr['image'], $arr['price'], $arr['duration'], $arr['countClass']);
                if ($stmt->execute()) {
                    $data["success"] = ' ավելացվել է ';
                } else {
                    $data["error"] = 'Չհաջողվեց ավելացնել';
                }
            } else {
                $data["error"] = $error;
            }
            $data['fetchAllCourses'] = $this->getAllCourses($page, $col, $order, "");
            $data['selectedCourses'] = $this->getSelectedCourses();
            $data['countCoursesPage'] = $this->countPage('courses', "");
        }


        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function editStudent(array $arr, $page, $col, $order)
    {
        $conn = $this->connect();
        $arr = $this->mysql_fix_string($arr, $conn);
        $data = array(
            'emptyErr' => "",
            'error' => "",
            'success' => "",
            'fetchStudents' => [],
            'selectedCourses' => [],
            "countStudentsPage" => "",
        );
        if ($arr['editname'] == "" || $arr['editsname'] == "" || $arr['editgender'] == "") {
            $data['emptyErr'] = "Լրացնել բոլոր դաշտերը";
        }
        if ($data['emptyErr'] == "") {
            $error = $this->validatStudentInfo($arr['editname'], $arr['editsname'], $arr['editgender']);
            if ($error == "") {
                if (file_exists($_FILES['editimage']['tmp_name']) || is_uploaded_file($_FILES['editimage']['tmp_name'])) {
                    $query = $conn->prepare("SELECT * FROM `students` WHERE `Id`=?");
                    $query->bind_param("i", $arr['editid']);
                    $query->execute();
                    $result = $query->get_result();
                    $fetch = $result->fetch_assoc();

                    $this->image_remove($fetch['Img']);
                    $imgpath = $this->image_upload($_FILES['editimage']);

                    $stmt = $conn->prepare("UPDATE `students` SET `Name`= ?,`Sname`=?,`Bday`=?,`Gender`=?,`Img`=?
                        WHERE `Id`=?");
                    $stmt->bind_param("sssssi", $arr['editname'], $arr['editsname'], $arr['editbday'], $arr['editgender'], $imgpath, $arr["editid"]);

                } else {
                    $stmt = $conn->prepare("UPDATE `students` SET `Name`= ?,`Sname`=?,`Bday`=?,`Gender`=?
                        WHERE `Id`=?");
                    $stmt->bind_param("ssssi", $arr['editname'], $arr['editsname'], $arr['editbday'], $arr['editgender'], $arr["editid"]);
                }

                if ($stmt->execute()) {
                    $data["success"] = ' տվյալները փոխվեցին';
                } else {
                    $data["error"] = 'Չհաջողվեց փոփոխել';
                }
            } else {
                $data['error'] = $error;
            }

            $data['fetchStudents'] = $this->getAllStudents($page, $col, $order, "");
            $data['selectedCourses'] = $this->getSelectedCourses();
            $data['countStudentsPage'] = $this->countPage('students', "");
        }
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function editCourses(array $arr, $page, $col, $order)
    {
        $conn = $this->connect();
        $arr = $this->mysql_fix_string($arr, $conn);
        $data = array(
            "emptyErr" => "",
            'error' => "",
            'success' => "",
            'fetchAllCourses' => [],
            'selectedCourses' => [],
            'countCoursesPage' => "",
        );
        if ($arr['editcoursName'] == "" || $arr['editlevel'] == "" || $arr['editimg'] == "" || $arr['editprice'] == "" || $arr['editduration'] == "" || $arr['editcountClass'] == "") {
            $data['emptyErr'] = "Լրացնել բոլոր դաշտերը";
        }
        if ($data['emptyErr'] == "") {
            $error = $this->validatCoursesInfo($arr['editcoursName'], $arr['editlevel'], $arr['editimg'], $arr['editprice'], $arr['editduration'], $arr['editcountClass']);
            if ($error == "") {
                $stmt = $conn->prepare("UPDATE `courses` SET `coursName`= ?,`level`=?,`Img`=?,`price`=?,`duration`=?,`countClass` =?
                WHERE `Id`=?");
                $stmt->bind_param("sssiisi", $arr['editcoursName'], $arr['editlevel'], $arr['editimg'], $arr['editprice'], $arr['editduration'], $arr['editcountClass'], $arr["editid"]);

                if ($stmt->execute()) {
                    $data["success"] = ' տվյալները փոխվեցին';
                } else {
                    $data["error"] = 'Չհաջողվեց փոփոխել';
                }
            } else {
                $data["error"] = $error;
            }
            $data['fetchAllCourses'] = $this->getAllCourses($page, $col, $order, "");
            $data['selectedCourses'] = $this->getSelectedCourses();
            $data['countCoursesPage'] = $this->countPage('courses', "");
        }
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function delete($id)
    {
        $conn = $this->connect();
        $data = array(
            'error' => "",
            'success' => "",
        );

        $stmt = $conn->prepare("UPDATE `students` SET `deleted`='1' WHERE `Id`=?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $data["success"] = 'ջնջված է';
        } else {
            $data["error"] = 'Չհաջողվեց ջնջել ';
        }

        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function deleteCourses($id)
    {
        $conn = $this->connect();
      
        $data = array(
            'error' => "",
            'success' => "",
        );
        $stmt = $conn->prepare("UPDATE `courses` SET `deleted`='1' WHERE `Id`=?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $data["success"] = 'ջնջված է';
        } else {
            $data["error"] = 'Չհաջողվեց ջնջել ';
        }
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    public function connect()
    {
        $DB = new \Database();
        $conn = $DB->connectDB();
        $conn->set_charset("utf8");
        return $conn;
    }
    public function mysql_fix_string(array $metod, $conn)
    {
        foreach ($metod as $key => $value) {
            $metod[$key] = htmlentities($conn->real_escape_string($value));
        }
        return $metod;
    }
    function image_upload($img)
    {
        $tmp_loc = $img['tmp_name'];

        $new_name = random_int(11111, 99999) . $img['name'];
        $new_loc = $_SERVER['DOCUMENT_ROOT'] . "/public/uploads/" . $new_name;
        if (!move_uploaded_file($tmp_loc, $new_loc)) {
            $_SESSION['delete'] = 'Չհաջողվեց ավելացնել նկարը ';
        } else {
            return $new_name;
        }
    }
    function image_remove($img)
    {
        if (!unlink($_SERVER['DOCUMENT_ROOT'] . "/public/uploads/" . $img)) {
            $_SESSION['delete'] = 'Չհաջողվեց ջնջել նկարը';
            //$this->getAll();
        }
    }
    function selectGender($select, $page, $col, $order, $search)
    {
        $data = array(
            'error' => "",
            'success' => "",
            'fetchStudents' => [],
           // 'fetchCourses' => [],
            'selectedCourses' => [],
            "countStudentsPage" => "",
        );

        if ($select == "Բոլորը") {
            $data["fetchStudents"] = $this->getAllStudents($page, $col, $order, $search);
            $data['countStudentsPage'] = $this->countPage('students', $search);
        } else {
            $data["fetchStudents"] = $this->getFilteredGender($select, $page, $col, $order, $search);
            $data['countStudentsPage'] = $this->countPageSelected('students', $select);
        }

      //  $data['fetchCourses'] = $this->getAllCourses("", "", "", "");
        $data['selectedCourses'] = $this->getSelectedCourses();
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function selectLevel($select, $page, $col, $order, $search)
    {
        $DB = new \Database();
        $conn = $DB->connectDB();

        $data = array(
            'error' => "",
            'success' => "",
            'fetchAllCourses' => [],
            'fetchStudents' => [],
            'selectedCourses' => [],
            "countCoursesPage" => "",
        );


        if ($select == "Բոլորը") {

            $data['fetchAllCourses'] = $this->getAllCourses($page, $col, $order, $search);
            $data['countCoursesPage'] = $this->countPage('courses', $search);
        } else {

            $data["fetchAllCourses"] = $this->getFilteredCourses($select, $page, $col, $order, $search);
            $data['countCoursesPage'] = $this->countPageSelected('courses', $select);

        }
        $data['fetchStudents'] = $this->getAllStudents($page, $col, $order, "");
        $data['selectedCourses'] = $this->getSelectedCourses();

        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    function getAllStudents($page, $col, $order, $search)
    {
        if (($col == "" && $order == "") || ($col == "coursName" || $col == "level" || $col == "price" || $col == "duration" || $col == "countClass")) {
            $col = "Id";
            $order = "ASC";
        } else if ($col !== "totalPrice" && $col !== "DiscountPrice") {
            $col = "students." . $col;
        }
        $page = (int) $page - 1;
        $page = $page * 5;
        $conn = $this->connect();
        $fetch = [];

        $query = $conn->prepare("SELECT 
                                    students.*, 
                                     IFNULL(SUM(courses.price * courses.duration), 0) AS totalPrice,
 	                                 IFNULL(SUM(courses.price * courses.duration)* 
                                        IF(SUM(courses.price * courses.duration) > 150000,
                                            IF(SUM(courses.price * courses.duration) > 200000,
                                                IF(SUM(courses.price * courses.duration) > 500000,
                                                .65,
                                            .75),
                                        .85)
                                        ,1),0) AS  DiscountPrice
                        FROM 
                            students
                        LEFT JOIN 
                            selected ON students.Id = selected.studentsId AND selected.deleted = '0'
                        LEFT JOIN 
                            courses ON selected.coursesId = courses.Id AND courses.deleted = '0'
                        WHERE 
                            students.user = '1' AND students.deleted = '0' AND (CONCAT(students.`Name`,' ',students.`Sname`) LIKE ? OR `Bday` LIKE ?)   
                        GROUP BY students.Id
                        ORDER BY  $col $order
                        LIMIT  5 OFFSET ?");

        $search = trim($search);
        $search = preg_replace('/\s+/', ' ', $search);
        $search = '%' . $search . '%';
        $query->bind_param("ssi", $search, $search, $page);
        $query->execute();
        $result = $query->get_result();

        while ($row = $result->fetch_assoc()) {
            array_unshift($fetch, $row);
        }
        return $fetch;
    }
    function moreCours($id)
    {
        $conn = $this->connect();
        $fetch = [];
        $query = $conn->prepare("SELECT  students.*, SUM(courses.price * courses.duration) AS totalPrice, 
                    SUM(courses.price * courses.duration)* 
                        IF(SUM(courses.price * courses.duration) > 150000,
                            IF(SUM(courses.price * courses.duration) > 200000,
                                IF(SUM(courses.price * courses.duration) > 500000,
                                .65,
                            .75),
                        .85)
                    ,1) AS DiscountPrice  FROM selected
                    JOIN students ON selected.studentsId = students.Id
                    JOIN courses ON selected.coursesId = courses.Id
                WHERE selected.coursesId=? AND students.user = '1'  AND students.deleted = '0' AND courses.deleted = '0' AND selected.deleted = '0'
                GROUP BY students.Id");
        $query->bind_param("i", $id);
        $query->execute();
        $result = $query->get_result();

        while ($row = $result->fetch_assoc()) {
            array_unshift($fetch, $row);
        }

        echo (json_encode($fetch, JSON_UNESCAPED_UNICODE));
    }
    function getAllCourses($page, $col, $order, $search)
    {
        if (($col == "" && $order == "") || ($col != "coursName" && $col != "duration" && $col != "level" && $col != "price" && $col != "countClass")) {
            $col = "Id";
            $order = "ASC";
        }
        $page = (int) $page - 1;
        $page = $page * 5;
        $conn = $this->connect();
        $fetch = [];

        if ($search == "") {
            $search = '%%';
        } else {
            $search = trim($search);
            $search = preg_replace('/\s+/', ' ', $search);
            $search = '%' . $search . '%';
        }

        if ($page == "") {
            $query = "SELECT * FROM `courses` WHERE `deleted`='0'";
            $result = $conn->query($query);
        } else {
            $query = $conn->prepare("SELECT * from courses WHERE  `deleted` = '0' AND  `coursName` LIKE ?  ORDER BY  $col $order LIMIT 5 OFFSET  ? ");
            $query->bind_param("si", $search, $page);
            $query->execute();
            $result = $query->get_result();
        }

        while ($row = $result->fetch_assoc()) {
            array_unshift($fetch, $row);
        }

        return $fetch;
    }
    function getSelectedCourses()
    {
        $conn = $this->connect();
        $fetch = [];
        $query = "SELECT students.Id,students.Name,students.Sname,students.Bday,students.email, coursesId,  courses.coursName,courses.level,courses.duration,courses.price, 
                    SUM(courses.price * courses.duration) AS totalPrice, 
                    SUM(courses.price * courses.duration)* 
                        IF(SUM(courses.price * courses.duration) > 150000,
                            IF(SUM(courses.price * courses.duration) > 200000,
                                IF(SUM(courses.price * courses.duration) > 500000,.65,.75),.85),1) AS DiscountPrice 
                        FROM selected 
                        JOIN courses ON selected.coursesId = courses.Id 
                        JOIN students ON selected.studentsId = students.Id 
                        WHERE students.userName != 'admin' AND selected.deleted = '0' AND students.deleted = '0' AND courses.deleted = '0'
                        GROUP BY `studentsId`,`coursesId`;";
        $result = $conn->query($query);

        while ($row = $result->fetch_assoc()) {
            array_unshift($fetch, $row);
        }

        return $fetch;
    }
    function getFilteredGender($select, $page, $col, $order, $search)
    {
        if ($col == "" && $order == "") {
            $col = "Id";
            $order = "ASC";
        } else if ($col !== "totalPrice" && $col !== "DiscountPrice") {
            $col = "students." . $col;
        }
        if ($search == "") {
            $search = '%%';
        } else {
            $search = trim($search);
            $search = preg_replace('/\s+/', ' ', $search);
            $search = '%' . $search . '%';
        }
        $page = (int) $page - 1;
        $page = $page * 5;
        $conn = $this->connect();
        $fetch = [];
        $stmt = $conn->prepare("SELECT 
                                    students.*, 
                                     IFNULL(SUM(courses.price * courses.duration), 0) AS totalPrice,
 	                                 IFNULL(SUM(courses.price * courses.duration)* 
                                        IF(SUM(courses.price * courses.duration) > 150000,
                                            IF(SUM(courses.price * courses.duration) > 200000,
                                                IF(SUM(courses.price * courses.duration) > 500000,
                                                .65,
                                            .75),
                                        .85)
                                        ,1),0) AS  DiscountPrice
                        FROM 
                            students
                        LEFT JOIN 
                            selected ON students.Id = selected.studentsId AND selected.deleted = '0'
                        LEFT JOIN 
                            courses ON selected.coursesId = courses.Id AND courses.deleted = '0'
                        WHERE 
                            students.user = '1' AND students.deleted = '0'  AND `Gender` LIKE   ? AND (CONCAT(students.`Name`,' ',students.`Sname`) LIKE ?  OR `Bday` LIKE ?) 
                        GROUP BY students.Id
                        ORDER BY  $col $order
                        LIMIT  5 OFFSET ?");
        $search = trim($search);
        $search = preg_replace('/\s+/', ' ', $search);
        $search = '%' . $search . '%';
        $e = $select;
        $select = '%' . $e . '%';

        $stmt->bind_param("sssi", $select, $search, $search, $page);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            array_unshift($fetch, $row);
        }

        return $fetch;
    }
    function getFilteredCourses($select, $page, $col, $order, $search)
    {
        if ($col == "" && $order == "") {
            $col = "Id";
            $order = "ASC";
        }
        if ($search == "") {
            $search = '%%';
        } else {
            $search = trim($search);
            $search = preg_replace('/\s+/', ' ', $search);
            $search = '%' . $search . '%';
        }
        $page = (int) $page - 1;
        $page = $page * 5;
        $conn = $this->connect();
        $fetch = [];
        $stmt = $conn->prepare("SELECT * FROM `courses` WHERE `level` LIKE ? AND `coursName` LIKE ?
                                         ORDER BY $col $order  LIMIT 5 OFFSET  $page ");
        
        $select = '%' . $select . '%';
        $stmt->bind_param("ss", $select, $search);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            array_unshift($fetch, $row);
        }

        return $fetch;
    }
    function onLoad($page, $col, $order, $search)
    {
        header("Content-type: application/json; charset=utf-8");
        $data = array(
            'error' => "",
            'success' => "",
            'fetchStudents' => [],
            'fetchAllCourses' => [],
            'selectedCourses' => [],
            'countStudentsPage' => "",
            'countCoursesPage' => "",
        );
        $data['fetchStudents'] = $this->getAllStudents($page, $col, $order, $search);
        $data['selectedCourses'] = $this->getSelectedCourses();
        $data['fetchAllCourses'] = $this->getAllCourses($page, $col, $order, $search);
        $data['countStudentsPage'] = $this->countPage('students', $search);
        $data['countCoursesPage'] = $this->countPage('courses', $search);
        echo (json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    function random_username($conn)
    {
        $user = "user";
        $lower_case = "abcdefghijklmnopqrstuvwxyz";
        $numbers = "1234567890";
        $symbols = "._-";
        $lower_case = str_shuffle($lower_case);
        $numbers = str_shuffle($numbers);
        $symbols = str_shuffle($symbols);

        $random_username = $user;
        $random_username .= substr($symbols, 0, 1);
        $random_username .= substr($lower_case, 0, 3);
        $random_username .= substr($numbers, 0, 2);

        $stmt = $conn->prepare("SELECT * FROM `students` WHERE userName =? ");
        $stmt->bind_param("s", $random_username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $this->random_username($conn);
        }
        return $random_username;
    }
    function countPage($table, $search)
    {
        $conn = $this->connect();

        if ($search !== "") {
            $search = trim($search);
            $search = preg_replace('/\s+/', ' ', $search);
            $search = '%' . $search . '%';
        } else {
            $search = '%%';
        }

        if ($table == "students") {
            $query = "SELECT  CEIL(COUNT(`Id`)/5) AS count FROM $table WHERE `user` = '1' AND `deleted`=0 AND (CONCAT(`Name`,' ',`Sname`) LIKE '$search' OR `Bday` LIKE '$search')";
        } else {
            $query = "SELECT  CEIL(COUNT(`Id`)/5) AS count FROM $table WHERE  `deleted`=0 AND `coursName` LIKE '$search' ";
        }
        $result = $conn->query($query);
        $result = $result->fetch_assoc();
        return $result['count'];

    }
    function countPageSelected($table, $select)
    {
        $conn = $this->connect();
        if ($table == "students") {
            $stmt = $conn->prepare("SELECT CEIL(COUNT(`Id`)/5) AS count FROM $table WHERE `user` = '1' AND `deleted` = '0' AND `Gender` LIKE ? ");
        } else {
            $stmt = $conn->prepare("SELECT CEIL(COUNT(`Id`)/5) AS count FROM $table WHERE `deleted` = '0' AND `level` LIKE ? ");
        }

        $e = $select;
        $select = '%' . $e . '%';
        $stmt->bind_param("s", $select);

        $stmt->execute();
        $result = $stmt->get_result();
        $result = $result->fetch_assoc();
        return $result['count'];
    }
    function validatStudentInfo($name, $lname, $gender)
    {
        $error = "";
        $sanitized_name = filter_var($name, FILTER_SANITIZE_STRING);
        $sanitized_lname = filter_var($lname, FILTER_SANITIZE_STRING);
        if (!preg_match('/[\p{Armenian}]/u', $sanitized_name)) {
            $error = 'Սխալ Անուն,օգտագործել միայն տառեր';
        } else if (!preg_match('/[\p{Armenian}]/u', $sanitized_lname)) {
            $error = "Սխալ Ազգանուն,օգտագործել միայն տառեր";
        } else if (strtolower($gender) == "իգական" || strtolower($gender) == "արական") {
            $error = "";
        } else {
            $error = "Սխալ,ընտրել սեռը";
        }

        /* $sanitized_email = filter_var($email, FILTER_SANITIZE_EMAIL);
     if (empty($name) || !filter_var($sanitized_email, FILTER_VALIDATE_EMAIL)) {
         $error .="Սխալ Էլ․ հասցե";
     }*/

        return $error;
    }
    function validatCoursesInfo($name, $level, $img, $price, $duration, $countClasses)
    {
        $error = "";
        $sanitized_name = filter_var($name, FILTER_SANITIZE_STRING);
        $img = filter_var($img, FILTER_SANITIZE_URL);

        if (!preg_match('/ [a-zA-Z]/', $sanitized_name)) {
            $error = 'Սխալ Անուն,օգտագործել միայն տառեր';
        } else if (preg_match('/^d+$/', $duration)) {
            $error = "Սխալ, ամիսների քանակը պետք է լինի միայն թվեր";
        } else if (preg_match('/^d+$/', $price)) {
            $error = "Սխալ գին, ներմուծել միայն թվեր";
        }/*else if ( !preg_match('/^\d{1,2}\s(դաս)|(քննություն)\s\+\s\d{1,2}\s(դաս)|(քննություն)$/', $countClasses)){
       $error ="Ներմուծել ճիշտ ֆոռմատի դասընթացների քանակ,օր՝ 16 դաս + 1 քննություն";
   }*/ else if (!filter_var($img, FILTER_VALIDATE_URL)) {
            $error = "Ներմուծել նկարի ճիշտ հղում";
        } else if (strtolower($level) == "սկսնակ" || strtolower($level) == "միջին" || strtolower($level) == "պրոֆեսիոնալ") {
            $error = "";
        } else {
            $error = "Սխալ,ընտրել դասընթացի ճիշտ մակարդակ";
        }

        /* $sanitized_email = filter_var($email, FILTER_SANITIZE_EMAIL);
     if (empty($name) || !filter_var($sanitized_email, FILTER_VALIDATE_EMAIL)) {
         $error .="Սխալ Էլ․ հասցե";
     }*/
        return $error;
    }


}

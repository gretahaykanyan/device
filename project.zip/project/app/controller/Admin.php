<?php
namespace controller;
class Admin
{
    function studentsData(){
    
        if(isset($_GET['search'])){
            $search =$_GET['search'];
        }else{
            $search='';
        }
        if(isset($_GET['col']) && isset($_GET['order'])){
            $col = $_GET['col'];
            $order = $_GET['order'];
        }else{
            $col = $order = "";
        }
        if(!(isset($_GET['page']))){   
            $_GET['page'] = "1";
        }

        $admin = new \model\Admin;
        
        if ((isset($_POST['Name']) && isset($_POST['Sname'])  && isset($_POST['Gender'])) || ( array_key_exists('Name', $_POST) || array_key_exists('Sname', $_POST) || array_key_exists('Gender', $_POST) )) {   
            //Add Students
                $admin->addStudent($_POST,$_GET['page'],$col,$order,);exit;
    
            } else if (isset($_POST['editName']) || isset($_POST['editsname']) || isset($_POST['editbday']) || isset($_POST['editgender']) || isset($_POST['editimage'])) {
            //Edit Students  
                $admin->editStudent($_POST,$_GET['page'],$col,$order);exit;
    
            }else if ( isset($_GET["gender"]) && isset($_GET['page']) )  {
            //Filter Gender    
                $admin->selectGender($_GET["gender"],$_GET['page'],$col,$order,$search);  
                exit;
                
            }  else if(isset($_GET['delete']) ){
            //Delete Student
                $admin->delete($_GET['delete']);
    
            }  else if(isset($_GET['moreCours']) ){
    
                $admin->moreCours($_GET['moreCours']);
    
            } else {
              
             $admin->onLoad($_GET['page'],$col,$order,$search); 
             
            }
    }
    function coursesData(){
        if(isset($_GET['search'])){
            $search =$_GET['search'];
        }else{
            $search='';
        }
        if(isset($_GET['col']) && isset($_GET['order'])){
            $col = $_GET['col'];
            $order = $_GET['order'];
        }else{
            $col = $order = "";
        }
        if(!(isset($_GET['page']))){   
            $_GET['page'] = "1";
        }
        $admin = new \model\Admin;
        
         if (isset($_POST['coursName']) && isset($_POST['level']) && isset($_POST['duration']) && isset($_POST['price']) && isset($_POST['countClass']) && isset($_POST['image']) || ( array_key_exists('coursName', $_POST) || array_key_exists('duration', $_POST) || array_key_exists('countClass', $_POST) || array_key_exists('level', $_POST) || array_key_exists('price', $_POST) || array_key_exists('image', $_POST))) {
        //Add Courses   
            $admin->addCourses($_POST,$_GET['page'],$col,$order);exit;

        }if (isset($_POST['editcoursName']) || isset($_POST['editlevel']) || isset($_POST['editduration']) || isset($_POST['editprice']) || isset($_POST['editcountClass']) || isset($_POST['editimg'])) {
        //Edit Courses  
            $admin->editCourses($_POST,$_GET['page'],$col,$order);exit;

        } else if ( isset($_GET["level"]) && isset($_GET['page']) ) {
        //Filter Courses Level    
            $admin->selectLevel($_GET["level"],$_GET['page'],$col,$order,$search); 
            exit;

        } else if(isset($_GET['deleteCours']) ){
        //Delete Courses
            $admin->deleteCourses($_GET['deleteCours']);

        } else if(isset($_GET['moreCours']) ){

            $admin->moreCours($_GET['moreCours']);

        } else {
          
            $admin->onLoad($_GET['page'],$col,$order,$search); 
         
        }   
    }
    public  function show()
    {
        include_once "../app/view/admin_students.php";    
    }
    public  function students()
    {   
        include_once "../app/view/admin_students.php";    
    }
    
    public  function courses()
    {
        include_once "../app/view/admin_courses.php";    
 
    }

}


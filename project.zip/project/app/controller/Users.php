<?php

namespace controller;

class Users
{
    public function index()
    {
 
        unset($_SESSION["Id"]); unset($_SESSION["uname"]);
        $user = new \model\Users;
        
        if (isset($_POST['Name']) && isset($_POST['Sname']) && isset($_POST['Bday']) && isset($_POST['Gender']) && isset($_POST['userName']) && isset($_POST['password']) && isset($_POST['email'])) {
            
            $user->signUp($_POST);

        } elseif (isset($_POST['userName']) && isset($_POST['password'])) {
           
            $user->signIn($_POST);

        } elseif (isset($_POST['email']) && $_POST['email'] !== "") {
            
            $user->forgetPass($_POST);

        } elseif (isset($_POST['code'])) {
            
            $user->resetCode($_POST['code']);
            
        } elseif (isset($_POST['cpassword']) && $_POST['password']) {
            
            $user->changePass($_POST);
        }
        
    }

    public  function signin(){
      
        include_once "../app/view/signin.php";
            
    }
    public  function signup(){
      
        include_once "../app/view/signup.php";
            
    }
    public  function reset(){
      
        include_once "../app/view/reset-code.php";
         
    }
    public  function newpass(){
      
        include_once "../app/view/new-password.php";
            
    }
    public  function forgotpass(){
      
        include_once "../app/view/forgot-password.php";
         
    }
}


<?php
namespace controller;
class Students
{
    public  function show()
    {
        include_once "../app/view/students.php";    
    
    }
    public function index(){
      
        $students = new \model\Students;
        if( (isset($_POST['Name']) || isset($_POST['Sname']) || isset($_POST['Bday']) || isset($_POST['Gender']) || isset($_POST['userName']) || isset($_POST['password']) || isset($_POST['cpassword'])  )){
        //edit user info
            $students->change($_POST);
        
        } elseif(isset($_GET['change'])){
        //show user info   
              $students->getUserInfo($_SESSION['uname']);

        } elseif (isset($_GET['add'])){
        //add courses
            $students->addCourses($_GET['add'],$_SESSION['id']);

        }else if(isset($_GET['delete'])){
        //delete courses
            $students->delete($_SESSION['id'],$_GET['delete']);

        }else if(isset($_GET['deleteAll'])){
        //delete All selected courses
            $students->deleteAll($_GET['deleteAll']);

        } else{
            $students->courses($_SESSION['id']);
        }

  
    }
    
}
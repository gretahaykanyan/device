<?php 
Class Url 
{
	public $page = "";
    public $class ="users";
	public $method = "show";
	public $params =[];
	public function __construct()
	{
		$url = $this->splitURL();

 		if(file_exists("../app/controller/".ucfirst($url[0]) .".php"))
 		{
 			$this->page = ucfirst($url[0]);
			 $_SESSION['page']=	$url[0];
 			
 		}
        
        $href= "controller"."\\" .$this->page;
 		$this->class= new $href();

        if(isset($url[1])){
			if(method_exists($this->class,$url[1])){
				$this->method = $url[1];
			$_SESSION['pagination']=$url[1];
			}
		}
		$this->params = array_values($url);
		call_user_func_array([$this->class, $this->method],$this->params);
	
	} 
	public function splitURL()
	{
		$url = isset($_GET['url']) ? $_GET['url'] : "users/signin";
		return explode("/", filter_var(trim($url,"/"),FILTER_SANITIZE_URL));
	}
}


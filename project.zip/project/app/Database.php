<?php
class Database
{
    public function connectDB()
	{
		try{
          $db = new mysqli("localhost","root","","project");
          
			return $db ;
		}catch(Exception $e){

			die($e->getMessage());
		}
	}
    public function result($query){
        $conn = $this -> connectDB();
        $result = $conn -> query($query) or die("connection faild");
        return $result;
    }
    protected function creatDB(){
        $conn = $this -> connectDB();
    
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
    
        $db = "CREATE DATABASE IF NOT EXISTS `project`";
        if ($conn->query($db) === TRUE) {
          echo "Database created successfully";
        } else {
          echo "Error creating database: " . $conn->error;
        }
      }
    
     /* protected function createTable() {
        $conn = $this -> connectDB();

        $user = "CREATE TABLE IF NOT EXISTS `students` (
          
          )";
          
        $courses = "CREATE TABLE IF NOT EXISTS `courses` (
    
          )";
          
        if (($conn->query($user) === TRUE) && ($conn->query($courses) === TRUE)) {
          echo "Table created successfully";
        } else {
          echo "Error creating table: " . $conn->error;
        }
      }
      */
}
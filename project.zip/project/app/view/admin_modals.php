<div class="modal fade" id="edit" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Փոխել տվյալները</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                
                <form action="" method="post" id="editform"
                    class="d-flex  flex-column align-items-center justify-content-center  needs-validation"
                    enctype="multipart/form-data" novalidate>

                    <div class="input-field col-md-7">
                        <i class="bi bi-spellcheck col-10"></i>
                        <input class="form-control col-2" type="text" name="editname" placeholder="Անուն" id="editname"
                            required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-spellcheck col-2"></i>
                        <input class="form-control col-10" type="text" name="editsname" placeholder="Ազգանուն" id="editsname"
                            required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>

                    <div class="input-field col-md-7">
                        <i class="bi bi-cake2"></i>
                        <input class="form-control" type="date" name="editbday" placeholder="Ծննդյան ամսաթիվ"
                            id="editbday"  />
                    </div>
                    <div class="input-field">
                        <i class="bi bi-gender-ambiguous"></i>
                        <select class="form-select" aria-label="Տեսակ" id="editgender" name="editgender" required>
                            <option value="իգական">Իգական</option>
                            <option value="արական">Արական</option>
                        </select>
                    </div>

                    <div class="input-field">
                        <i class="bi bi-card-image">
                            <input class="form-control img" type="file" name="editimage" placeholder="Նկար" accept=".jpg,.png,.svg" /> 
                        </i>
                        <span id="image" class="image" style="max-height: 55px">Ուսանողի Նկար</span>
                    </div>
                    <input type="hidden" id="editid" name="editid" />
                    <button class="button" name="editStudent" id="edit_submit" type="submit">Փոխել</button>

                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="editCourses" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Փոխել տվյալները</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               
                <form action="" method="post" id="editCoursesform"
                    class="d-flex  flex-column align-items-center justify-content-center  needs-validation"
                    enctype="multipart/form-data" novalidate>

                    <div class="input-field col-md-7">
                        <i class="bi bi-spellcheck col-2"></i>
                        <input class="form-control col-10" type="text" name="editcoursName" placeholder="Դասընթացի անվանում"
                            id="editcoursName" required />
                            <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7 mt-4">
                        <i class="bi bi-list-ol col-2"></i>
                        <select class="form-select col-10" a-label="Սեռ" id="editlevel" name="editlevel" required>
                            <option value="սկսնակ">Սկսնակ</option>
                            <option value="միջին">Միջին</option>
                            <option value="պրոֆեսիոնալ">Պրոֆեսիոնալ</option>
                        </select>
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>

                    <div class="input-field col-md-7">
                        <i class="bi bi-calendar-range col-2"></i>
                        <input class="form-control col-10" type="number" name="editduration" placeholder="Տևողություն"
                            id="editduration" required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-calendar3-week col-2"></i>
                        <input class="form-control col-10" type="text" name="editcountClass" placeholder="Դասերի քանակ"
                            id="editcountClass" required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-currency-exchange col-2"></i>
                        <input class="form-control col-10" type="number" name="editprice" placeholder="Գին" id="editprice"
                            required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-card-image col-2"></i>
                        <input class="form-control col-10" type="text" name="editimg" placeholder="Նկար" id="editimg"
                            required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <input type="hidden" id="editCoursesId" name="editid" />
                    <button class="button" name="editCourses" id="editCourses_submit" type="submit">Փոխել</button>

                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="more" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Մանրամասն</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card m-auto">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="" class="img-fluid rounded-start" id="moreimg">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title"><span id="morename"></span> <span id="moresname"></span></h5>
                                <p class="card-text">
                                    Սեռ: <span id="moregender"></span><br>
                                    Ծննդյան ամսաթիվ: <span id="morebday"></span><br>
                                    Էլ․ հասցե: <span id="moreemail"></span><br>
                                    Մուտքանուն: <span id="moreuname"></span><br>
                                    Գաղտնաբառ: <span id="morepass"></span><br>
                                </p>

                                <table class="table mb-5 pb-5">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Անուն</th>
                                            <th scope="col">Տևող.</th>
                                            <th scope="col">Արժեք ամս․</th>
                                            <th scope="col">Ընդ․ արժեք</th>
                                            <th scope="col">Վերջ․ արժեք</th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody class="fetchCourses"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="moreCourses" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Մանրամասն</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card m-auto">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="" class="img-fluid rounded-start" id="morecoursimg">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title"><span id="morename"></span> <span id="moresname"></span></h5>
                                <p class="card-text">
                                    Դասընթացի անվանում: <span id="morecoursname"></span><br>
                                    Մակարդակ: <span id="morelevel"></span><br>
                                    Տևողություն: <span id="moreduration"></span><br>
                                    Դասերի քանակ: <span id="morecount"></span><br>
                                    Գին: <span id="moreprice"></span><br>

                                </p>

                                <table class="table mb-5 pb-5">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Անուն</th>
                                            <th scope="col">Էլ․ հասցե</th>
                                            <th scope="col">Ընդ․ արժեք</th>
                                            <th scope="col">Վերջ․ արժեք</th>

                                        </tr>
                                    </thead>
                                    <tbody class="fetchStudents"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="add" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Ավելացնել տվյալներ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                
                <form method="post"
                    class="d-flex  row align-items-centre justify-content-around text-center needs-validation form mt-md-2 p-3"
                    id="form" enctype="multipart/form-data" novalidate>    
                    <div class="input-field col-md-7">
                        <i class="bi bi-spellcheck col-2"></i>
                        <input class="form-control col-10" type="text" name="Name" placeholder="Անուն" id="name" required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-spellcheck col-2"></i>
                        <input class="form-control col-10" type="text" name="Sname" placeholder="Ազգանուն" id="sname"
                            required />
                            <div></div>
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>

                    <div class="input-field col-md-7">
                        <i class="bi bi-cake2 col-2"></i>
                        <input class="col-10" type="date" name="Bday" placeholder="Ծննդյան ամսաթիվ" id="bday" />
                    </div>
                    <div class="input-field col-md-7 mt-4">
                        <i class="bi bi-gender-ambiguous col-2"></i>
                        <select class="form-select col-10" aria-label="Սեռ" id="gender" name="Gender" required>
                            <option selected disabled value="">Սեռ</option>
                            <option value="իգական">Իգական</option>
                            <option value="արական">Արական</option>
                        </select>
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                 
                    <div class="input-field col-md-7">
                        <i class="bi bi-card-image col-2" style="max-height: 55px;"><input class=" " type="file" name="image"
                                placeholder="Նկար" id="img" accept=".jpg,.png,.svg,.webp" /> </i>
                        <span class="col-10" id="image">Լուսանկար</span>
                    </div>
                    <button class="button col-md-6 m-auto" name="add" id="submit" type="submit">Ավելացնել</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addCourses" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Ավելացնել դասընթացներ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               
                <form method="post"
                    class="d-flex  row align-items-centre justify-content-around text-center needs-validation mt-md-2 p-3"
                    id="formCourses" enctype="multipart/form-data" novalidate>
                    <div class="input-field col-md-7">
                        <i class="bi bi-spellcheck col-2"></i>
                        <input class="form-control col-10" type="text" name="coursName" placeholder="Դասընթացի անվանում"
                            id="coursName" required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7 mt-4">
                        <i class="bi bi-list-ol col-2"></i>
                        <select class="form-select col-10" a-label="Սեռ" id="level" name="level" value="" required>
                            <option value="" selected disabled>Մակարդակ</option>
                            <option value="սկսնակ">Սկսնակ</option>
                            <option value="միջին">Միջին</option>
                            <option value="պրոֆեսիոնալ">պրոֆեսիոնալ</option>
                        </select>
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>


                    <div class="input-field col-md-7">
                        <i class="bi bi-calendar-range col-2"></i>
                        <input class="form-control col-10" type="number" name="duration"
                            placeholder="Տևողություն (ամիսների քանակ)" id="duration" required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-calendar3-week col-2"></i>
                        <input class="form-control col-10" type="text" name="countClass"
                            placeholder="Դասերի քանակ (Օր․՝ 16 դաս + 1 քննություն)" id="countClass" required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-currency-exchange col-2"></i>
                        <input class="form-control col-10" type="number" name="price" placeholder="Գին" id="price" required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-card-image col-2"></i>
                        <input class="form-control col-10" type="text" name="image" placeholder="Նկար" id="img" required />
                        <div class="invalid-feedback col-8 text-start">Լրացնել պարտադիր դաշտերը</div>
                    </div>

                    <button class="button col-md-6 m-auto" name="add" value="add" id="submit" type="submit">Ավելացնել</button>
                </form>
            </div>
        </div>
    </div>
</div>
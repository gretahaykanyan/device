<div class="modal fade" id="change" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Փոխել տվյալներ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post"
                    class="d-flex  row align-items-centre justify-content-around text-center needs-validation mt-md-2 p-3"
                    id="form" enctype="multipart/form-data" novalidate>
                    <div class="input-field col-md-7">
                        <i class="bi bi-spellcheck"></i>
                        <input class="form-control" type="text" name="Name" placeholder="Անուն" id="name" required />
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-spellcheck"></i>
                        <input class="form-control" type="text" name="Sname" placeholder="Ազգանուն" id="sname"
                            required />
                    </div>

                    <div class="input-field col-md-7">
                        <i class="bi bi-cake2"></i>
                        <input class="form-control" type="date" name="Bday" placeholder="Ծննդյան ամսաթիվ" id="bday"
                            required />
                    </div>
                    <div class="input-field col-md-7 mt-4">
                        <i class="bi bi-gender-ambiguous"></i>
                        <select class="form-select" aria-label="Սեռ" id="gender" name="Gender" required>
                            <option selected disabled>Սեռ</option>
                            <option value="Իգական">Իգական</option>
                            <option value="Արական">Արական</option>
                        </select>
                    </div>
                    <div class="input-field col-md-7">
                        <i class="bi bi-card-image" style="max-height: 55px;"><input class="form-control " type="file"
                                name="image" placeholder="Նկար" id="img" accept=".jpg,.png,.svg,.webp" required /> </i>
                        <span id="image">Լուսանկար</span>
                    </div>
                    <div class="input-field">
                        <i class="bi bi-person-fill"></i>
                        <input class="form-control" type="text" name="userName" id="userName" placeholder="Մուտքանուն" required />
                    </div>
                    <div class="input-field">
                        <i class="bi bi-envelope-at-fill"></i>
                        <input class="form-control" type="email" name="email" id="email"  placeholder="էլ. հասցե" required />
                    </div>
                    <div class="input-field">
                        <i class="bi bi-lock-fill"></i>
                        <input class="form-control" type="password" id="cpassword" name="cpassword" placeholder="Հին գաղտնաբառ"
                            id="password" required />
                        <i class="bi bi-eye-slash-fill cpas_hidden"></i>
                    </div>
                    <div class="input-field">
                        <i class="bi bi-lock-fill"></i>
                        <input class="form-control" type="password" id="password" name="password" placeholder="Նոր գաղտնաբառ"
                            id="password" required />
                        <i class="bi bi-eye-slash-fill pas_hidden"></i>
                    </div>
                    <input type="hidden" id="id" name="id" />
                    <button class="button col-md-6 m-auto btnn" name="change" id="submit" type="submit">Փոխել</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include (__DIR__ . "\..\config.php");
if ($_SESSION['uname'] == false) {
  header('Location: users/signin');
}
$id =$_SESSION["id"];
?>

<!DOCTYPE html>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="<?= ROOT ?>css\style_students.css?v=<?php echo time(); ?>" />

  <title>Ուսանողներ</title>
</head>

<body>
<div class="loading "></div> 
  <div class="container-fluid h-100 w-100 p-0">
    <nav class="navbar navbar-expand-lg fixed-top  bd-gutter px-2 px-md-5 py-3">
      <div class="container-fluid">
        <a class="nav-link navbar-brand disabled" aria-disabled="true" href="#" style="color:#FBE175;"> <i
            class="bi bi-people-fill"></i> Students</a>

        <ul class="navbar-nav flex-row flex-wrap ms-md-auto p-0">
          <li class="nav-item">
            <a class="nav-link py-2 px-0 px-lg-2 btn-primary position-relative" data-bs-toggle="offcanvas"
              href="#offcanvasExample" role="button" aria-controls="offcanvasExample">
              <i class="bi bi-bag-check-fill"></i>
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger count">
                

                <span class="visually-hidden">unread messages</span>
              </span>
            </a>
          </li>
          <li class="nav-item py-2 py-lg-1 col-auto">
            <div class="vr d-flex h-100 mx-2 text-white"></div>

          </li>
          <li class="nav-item">
            <a class="nav-link d-flex list-inline align-items-center py-2 px-0 px-lg-2">
              <p class="h5 me-2 m-0 list-inline-item" id="signin"></p>
              <img src="<?= ROOT ?>/uploads/<?php echo $_SESSION["img"] ?>" class="student_img"> <span
                class="uname"><?php echo $_SESSION["uname"] ?></span>
            </a>
          </li>
          <li class="nav-item py-2 py-lg-1 col-auto">
            <div class="vr d-flex h-100 mx-2 text-white"></div>
          </li>
          <li class="nav-item dropdown">
            <button type="button"
              class="btn btn-link nav-link py-2 px-0 px-lg-2 dropdown-toggle d-flex align-items-center "
              data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-three-dots"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end p-1">


              <li class="change">
                <a class="dropdown-item  d-flex align-items-center">
                  <i class="bi bi-gear-fill me-2"></i>Փոխել տվյալնները
                </a>
              </li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item d-flex align-items-center" href="?logout"><i
                    class="bi bi-box-arrow-in-right me-2"></i><span>Դուրս գալ</span></a></li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
    <div class="toast-container d-flex justify-content-center align-items-center w-100">
      <div id="liveToast1" class="toast hide text-white bg-danger mt-5" role="alert" aria-live="assertive"
        aria-atomic="true" data-bs-delay="1000">
        <div class="toast-header">
          <strong class="me-auto">Զգուզացում</strong>
          <small>1 րոպե առաջ</small>
          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body error"></div>
      </div>

      <div id="liveToast2" class="toast hide text-white bg-info mt-5" role="alert" aria-live="assertive"
        aria-atomic="true" data-bs-delay="1000">
        <div class="toast-header">
          <strong class="me-auto">Զգուզացում</strong>
          <small>1 րոպե առաջ</small>
          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body success"></div>
      </div>
    </div>
    <div class="container-fluid row  px-3 px-sm-5 g-0 p-0 " style="position: relative;top: 150px;">
      <div class=" col-sm-3 ps-4 ps-sm-0 ps-mb-4 pb-5 pb-sm-0  filter">
        <form class="accordion" id="accordionExample">
          <div class="range mb-5">
            <div class="price-input">
              <div class="field">
                <span>Min</span>
                <input type="number" class="input-min " value="0">
              </div>
              <div class="separator">-</div>
              <div class="field">
                <span>Max</span>
                <input type="number" class="input-max " value="90000">
              </div>
            </div>
            <div class="slider">
              <div class="progress"></div>
            </div>
            <div class="range-input">
              <input type="range" class="range-min " min="0" max="90000" value="0" step="1000">
              <input type="range" class="range-max " min="0" max="90000" value="90000" step="1000">
            </div>
          </div>

          <div class="courses mt-2 accordion-item">
            <h5 class="accordion-header">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseCourses"
                aria-expanded="true" aria-controls="collapseOne">
                Դասընթացներ
              </button>
            </h5>
            <div id="collapseCourses" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
              <div class="accordion-body">

                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="Frontend" id="courses">
                  <label class="form-check-label" for="courses">
                    Frontend
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="UX/UI" id="courses1">
                  <label class="form-check-label" for="courses1">
                    UX/UI
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="SEO" id="courses2">
                  <label class="form-check-label" for="courses2">
                    SEO
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="Project Management" id="courses3">
                  <label class="form-check-label" for="courses3">
                    Project Management
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="Graphic Design" id="courses4">
                  <label class="form-check-label" for="courses4">
                    Graphic Design
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="SMM" id="courses5">
                  <label class="form-check-label" for="courses5">
                    SMM
                  </label>
                </div>

              </div>
            </div>

          </div>


          <div class="level mt-2 accordion-item">
            <h5 class="accordion-header">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseLevel"
                aria-expanded="true" aria-controls="collapseOne">
                Մակարդակ
              </button>
            </h5>
            <div id="collapseLevel" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
              <div class="accordion-body">

                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="սկսնակ" id="level">
                  <label class="form-check-label" for="level">
                    սկսնակ
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="միջին" id="level1">
                  <label class="form-check-label" for="level1">
                    միջին
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="պրոֆեսիոնալ" id="level2">
                  <label class="form-check-label" for="level2">
                    պրոֆեսիոնալ
                  </label>
                </div>

              </div>
            </div>

          </div>

        </form>
      </div>
      <div class="toast-container d-flex justify-content-center align-items-center w-100">

      </div>
      <div class="row col-12 col-sm-9 devices  justify-content-around g-0 ps-3 courses_cards">
        <!-- courses fetch -->
      </div>

    </div>




    <div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvasExample"
      aria-labelledby="offcanvasExampleLabel" data-bs-backdrop="false">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasExampleLabel">Ընտրված սարքավորումները</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"
          style="color: var(--green);"></button>
      </div>
      <div class="offcanvas-body">  
        <div style="color:white;background-color: #58a2a080;border-radius: 10px;padding: 15px;">150.000 Դր․ և ավելի ամրագրման դեպքում <span style="color: rgb(32, 162, 160);">15%</span> զեղչ, 200.000 Դր․ և ավելի  դեպքում <span style="color:#FBE175;">25%</span> զեղչ,500.000 Դր․ և ավելի  դեպքում <span style="color:#dc3545;">35%</span> զեղչ </div>
        <div class="cards_header d-inline-flex">
        
          <ul class="navbar-nav flex-row flex-wrap ms-md-auto p-0 justify-content-end">
            <li class="nav-item">
              Ընդհանուր
            </li>
            <li class="nav-item py-2 py-lg-1 col-auto">
              <div class="vr d-flex h-100 mx-2 text-white"></div>
            </li>
            <li class="nav-item totoal_price discount " style="color: var(--green);" >
              65․000Դր․
            </li>
            <li class="nav-item py-2 py-lg-1 col-auto">
              <div class="vr d-flex h-100 mx-2 text-white"></div>
            </li>
            <li class="nav-item discount_price" style="color: var(--yellow);" >
              65․000Դր․
            </li>
            <li class="nav-item py-2 py-lg-1 col-auto">
              <div class="vr d-flex h-100 mx-2 text-white"></div>
            </li>
            <li class="nav-item dropdown mt-3">
              <button class="btn btn-danger " type="button" onclick="removeAll(<?php echo $id; ?>)">Ջնջել
                բոլորը</button>
            </li>
          </ul>
        </div>
        <div class="offcanvas-cards px-4 pt-4">
          <!-- selected courses cards -->
        </div>

      </div>
    </div>

    <footer class="row text-center justify-content-center p-0 m-0"
      style="background-color: var(--green);position: relative;top: 300px;">2024</footer>
    <?php include_once (__DIR__ . "\students_changepass.php") ?>
  </div>


  <script src="<?= ROOT ?>js/students.js?v=<?php echo time(); ?>"></script>
  <script src="<?= ROOT ?>js/action_students.js?v=<?php echo time(); ?>"></script>
  <script src="<?= ROOT ?>js/pass.js?v=<?php echo time(); ?>"></script>
</body>

</html>
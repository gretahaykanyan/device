<?php include (__DIR__ . "\..\config.php");
if ($_SESSION['uname'] == false) {
    header('Location: ../users/signin');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?= ROOT ?>css\style_admin.css?v=<?php echo time(); ?>" />
    <title>Admin</title>
</head>

<body>
    <div class="loading "></div>
    <div class="container-fluid row p-3 g-0 h-100">

        <div class="container-fluid col-12  panel tab-content" id="pills-tabContent">
            <nav class="navbar navbar-expand-lg bg-body-tertiary mt-4">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">
                        <i class="bi  bi-person-badge-fill"></i>
                        <?php echo $_SESSION["uname"] ?>
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText"
                        aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse px-4" id="navbarText">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item me-3">
                                <a class="nav-link " aria-current="page" href="<?= ROOT ?>admin/students">Students</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="<?= ROOT ?>admin/courses">Courses</a>
                            </li>
                            <li class="nav-item ms-5">
                                <a class="nav-link d-flex" href="?logout" style="color:var(--green);"> <i
                                        class="bi bi-box-arrow-in-right px-3"></i>Դուրս գալ</a>
                            </li>
                        </ul>

                    </div>
                </div>
            </nav>
            <div class="toast-container d-flex justify-content-center align-items-center w-100">
                <div id="liveToast1" class="toast hide text-white bg-danger mt-5" role="alert" aria-live="assertive"
                    aria-atomic="true" data-bs-delay="1000">
                    <div class="toast-header">
                        <strong class="me-auto">Զգուզացում</strong>
                        <small>1 րոպե առաջ</small>
                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                    <div class="toast-body error"></div>
                </div>

                <div id="liveToast2" class="toast hide text-white bg-info mt-5" role="alert" aria-live="assertive"
                    aria-atomic="true" data-bs-delay="1000">
                    <div class="toast-header">
                        <strong class="me-auto">Զգուզացում</strong>
                        <small>1 րոպե առաջ</small>
                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                    <div class="toast-body success"></div>
                </div>
            </div>
            <div class="panel_inner home tab-pane fade show active" id="pills-home" role="tabpanel"
                aria-labelledby="pills-home-tab">
                <div class="row justify-content-between align-items-start mb-3 p-0">
                    <h3 class="col">Դասընթացների ցուցակ</h3>
                    <div class="col d-flex justify-content-end p-0">
                        <button type="button" class="btn btnn add me-3 mb-1" style="--l: #085736;--i:#b1ffdfdb;">
                            <i class="bi bi-backpack-fill"></i></button>
                        <form method="post" id="selectCourses">
                            <div class="btn-group me-3">
                                <select class="form-select selectlevel" name="level">
                                    <option value="Բոլորը" selected>Մակարդակ</option>
                                    <option value="Սկսնակ">Սկսնակ</option>
                                    <option value="Միջին">Միջին</option>
                                    <option value="Պրոֆեսիոնալ">Պրոֆեսիոնալ</option>
                                </select>
                            </div>
                        </form>
                        
                    </div>
                    <form class="d-flex col search" role="search" >
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>

                <div class="tab col-12   justify-content-start p-0">
                    <table class="table mb-5 pb-5">
                        <thead>
                            <tr>
                                <th scope="col" data-index ="Id"># <i class="bi bi-arrow-down"></i></th> 
                                <th scope="col" >ՆԿԱՐ </th>
                                <th scope="col" data-index ="coursName">Անվանում <i class="bi bi-arrow-down"></i></th>
                                <th scope="col" data-index ="level">Մակարդակ <i class="bi bi-arrow-down"></i></th>
                                <th scope="col" data-index ="price">Գին <i class="bi bi-arrow-down"></i></th>
                                <th scope="col" data-index ="duration">Տևողություն <i class="bi bi-arrow-down"></i></th>
                                <th scope="col" data-index ="countClass">Դասերի քանակ <i class="bi bi-arrow-down"></i></th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody class="fetch"></tbody>
                    </table>
                </div>

                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                            <!-- pages-->
                    </ul>
                </nav>
            </div>
        </div>

    </div>

    <?php include_once (__DIR__ . "\admin_modals.php") ?>
    </div>


    <script src="<?= ROOT ?>js/action_adminCourses.js?v=<?php echo time(); ?>"></script>
    <script src="<?= ROOT ?>js/admin.js?v=<?php echo time(); ?>"></script>

</body>

</html>
let form = document.querySelector("#form");
let total = document.querySelector(".totoal_price");
let discount = document.querySelector(".discount_price");
document.querySelector(".offcanvas-cards").innerHTML="";
document.querySelector(".courses_cards").innerHTML="";


let changeModal = new bootstrap.Modal(document.getElementById('change'), {
    keyboard: false
});

document.querySelector(".change").onclick = async function (e) {
    e.preventDefault();


    let response = await fetch('../public/post.php?change=1',{
        header:{
            "Content-type": "application/json; charset=utf-8"
        }
    }).catch((error) => console.error(error));
    if (response.ok) {
        response.json().then(function (text) {
            let fetch = text[0];
            
            change(fetch);


        })
    }
}

document.querySelector("body").onload =async function(e){
    e.preventDefault();
	let response = await fetch('../public/post.php').catch((error) => console.error(error));
    
    if (response.ok) {
        response.json().then(function (text) {
            let fetch_courses = text.fetchCourses;
            let fetch_selected = text.fetchSelected;
            document.querySelector(".count").innerHTML =text.count;
                    for(let i=fetch_courses.length-1; i >=0 ;i--){
                        
                        let fetchArr =[];
                        for( const [key,value] of Object.entries(fetch_courses[i])){
                            fetchArr[`${key}`]=  `${value}`;

                        }  
                        for(let j=0;j< fetch_selected.length;j++){
                                 let id = fetch_selected[j].coursesId; 
                                //console.log(id);  
                                // console.log(fetch_courses[i].coursId);  
                               
                                if(fetch_courses[i].Id == id){
                                    fetchArr['btnSelected'] =true;
                                    break;
                                }else{
                                 
                                    fetchArr['btnSelected'] =false;
                                }
                        }
                            create_card(fetchArr,i);

                    }
                
           
                for(let i=fetch_selected.length-1; i >=0 ;i--){
                
                    let fetchSelArr =[];
                    for( const [key,value] of Object.entries(fetch_selected[i])){
                        fetchSelArr[`${key}`]=  `${value}`;
                    }
                
                create_selectedCard(fetchSelArr);
                }
              
                if(text.price["totalPrice"] == null){
                    text.price["totalPrice"] ="0";
                    text.price["DiscountPrice"] ="0";
                }
             discount.innerHTML = parseInt(text.price["DiscountPrice"]) + " Դր․";   
             total.innerHTML = text.price["totalPrice"] + " Դր․";   
             priceChenge(total,discount);
        })
    }
}

form.onsubmit = async function (e) {
    e.preventDefault();

    document.querySelector(".error").parentElement.classList.remove("show");
    document.querySelector(".error").textContent="";
    document.querySelector(".success").parentElement.classList.remove("show");
    document.querySelector(".success").textContent="";


    let formData = new FormData(form);

    let response = await fetch('../public/post.php', {
        method: "POST",
        body: formData,
    });
    if (response.ok) {
        response.json().then(function (text) {
           
           
            if(text.error !== ''){
                document.querySelector(".error").parentElement.classList.add("show");
                document.querySelector(".error").textContent=text.error;
            }else if(text.success !== ''){
                document.querySelector(".success").parentElement.classList.add("show");
                document.querySelector(".success").textContent=text.success;
            } else {
                console.log("not send");
            }
            
            document.querySelector('.student_img').src = 'uploads/' + text.img;
            document.querySelector('.uname').innerHTML = text.uname;

            let divAlert = create_element("div",text.passerror);
            if(text.passerror !== ''){
                
                divAlert.classList.add("alert","alert-danger");
                if(form.hasChildNodes(divAlert)){
                   divAlert.remove();
                }
                 form.appendChild(divAlert);
            }else{
               
                if(form.hasChildNodes(divAlert)){
                    divAlert.remove();
                }
               
                form.reset();
                changeModal.hide();
            }
        })
        
        }
    }
   
let addCours = async function(id,btn){
  
    document.querySelector(".offcanvas-cards").innerHTML="";
    let response = await fetch('../public/post.php?add='+id).catch((error) => console.error(error));
    console.log(response);
    if(response.ok){
        response.json().then(function(text){
           
            let fetch_selected = text.fetchSelected;
         
            if(text.error !== ''){
                btn.classList.remove("add_btn_hover");
                btn.disabled = false;
            }else if(text.success !== ''){
               btn.classList.add("add_btn_hover");
                btn.disabled = true;
            }
            document.querySelector(".count").innerHTML =text.count;
            for(let i=fetch_selected.length-1; i >=0 ;i--){
            
                let fetchSelArr =[];
                for( const [key,value] of Object.entries(fetch_selected[i])){
                    fetchSelArr[`${key}`]=  `${value}`;
                }
                
            console.log(fetchSelArr);
            create_selectedCard(fetchSelArr);
            }

            discount.innerHTML = parseInt(text.price["DiscountPrice"]) + " Դր․";   
             total.innerHTML = text.price["totalPrice"] + " Դր․";   
             priceChenge(total,discount);
             
        })
    }
}

let removeCours = async function(coursId, row,h5){
    row.remove();
    let response = await fetch('../public/post.php?delete='+coursId).catch((error) => console.error(error));

    if(response.ok){  
        response.json().then(function(text){
           
            if(text.error !== ''){
                console.log(text.error);
            }else if(text.success !== ''){
              document.querySelectorAll(".cours_name ").forEach( (value,key,list)=>{
                
                    if(value.innerHTML== h5.innerHTML){
                        let card = list[key].parentElement;
                        let  btn = card.lastChild;
                        btn.classList.remove("add_btn_hover");
                        btn.disabled = false;
                    }
                })
            }  
            document.querySelector(".count").innerHTML =text.count;
            if(text.price["totalPrice"] == null){
                text.price["totalPrice"] ="0";
                text.price["DiscountPrice"] ="0";
            }    
        discount.innerHTML = parseInt(text.price["DiscountPrice"]) + " Դր․";   
        total.innerHTML = text.price["totalPrice"] + " Դր․"; 
        
        priceChenge(total,discount);
        
    })
    }
}

let removeAll = async function(Id){
  if(confirm("Ջնջել բոլորը")){
    document.querySelectorAll(".offcanvas-cards .card").forEach((card)=>{
        card.remove();
    });
 
    let response = await fetch('../public/post.php?deleteAll='+Id).catch((error) => console.error(error));

    if(response.ok){  
        response.json().then(function(text){
           
            if(text.error !== ''){
                console.log(text.error);
            }else if(text.success !== ''){
              document.querySelectorAll(".add_btn ").forEach( (btn)=>{
                        console.log(btn);
                        btn.classList.remove("add_btn_hover");
                        btn.disabled = false;
                    
                })
            } 
            document.querySelector(".count").innerHTML =text.count;
            if(text.price["totalPrice"] == null){
                text.price["totalPrice"] ="0";
                text.price["DiscountPrice"] ="0";
            }
            discount.innerHTML = parseInt(text.price["DiscountPrice"]) + " Դր․";   
            total.innerHTML = text.price["totalPrice"] + " Դր․";   
           
           
            priceChenge(total,discount);
        })
    }
  }
}

let create_button = function (){
    const button = document.createElement("BUTTON");
    const i = document.createElement("i");

    button.type = "button";
   
    button.classList.add("btn", "btn-primary", "fs-md-5", "fs-6","add_btn");
    
    i.classList.add("bi");
    i.classList.add("bi-patch-check", "me-3");
    i.appendChild(document.createTextNode("Ավելացնել"))
    button.appendChild(i);
   
    return button;
}

let create_element = function (element,inner){
    const para = document.createElement(""+element+"");
    const node = document.createTextNode(""+inner+"");
    para.appendChild(node);
    
    return para;
}

let create_card = function(fetch,i){
    
    let card = document.createElement("div");
    card.classList.add("card", "cart" ,"mb-5");

    let img = document.createElement("img");
    img.classList.add("card-img-top");
    img.src =fetch.Img;
    card.appendChild(img);

    let card_body = document.createElement("div");
    card_body.classList.add("card-body","d-flex", "flex-column", "justify-content-between");

    let h5 = create_element("h5",fetch.coursName);
    h5.classList.add("card-title", "text-center", "cours_name");
    card_body.appendChild(h5);

    let level = create_element("p",fetch.level);
    level.classList.add("card-text", "level_m");
    card_body.appendChild(level);

    let dur_b=create_element("b","Տևողություն: ");
    let duration = document.createElement("p");
    duration.appendChild(dur_b);
    duration.appendChild(document.createTextNode(fetch.duration + " ամիս"));
    card_body.appendChild(duration);

    let class_b =create_element("b","Դասերի քանակ: ");
    let classes = document.createElement("p");
    classes.appendChild(class_b);
    classes.appendChild(document.createTextNode( fetch.countClass));
    card_body.appendChild(classes);

    let price =document.createElement("p");
    price.appendChild(document.createTextNode("Ամսական "));
    let span =create_element("span", fetch.price );
    span.classList.add("price","priceCard");
    price.appendChild(span);
    price.appendChild(document.createTextNode(" Դր."));
    card_body.appendChild(price);

    let add = create_button();
    card_body.appendChild(add);
    card.appendChild(card_body);
    add.onclick = function () {addCours(fetch.Id,this)};

    if(fetch.btnSelected){
        add.classList.add("add_btn_hover");
        add.disabled = true;
    }else{
        add.classList.remove("add_btn_hover");
        add.disabled = false;
    }
    document.querySelector(".courses_cards").appendChild(card) ; 
}

let create_selectedCard = function(fetch,i){
    let card = document.createElement("div");
    card.classList.add("card","mb-3");

    let row = document.createElement("div");

    row.classList.add("row", "g-0", "align-items-center");

    let img = document.createElement("img");
    img.classList.add("img-fluid", "rounded-start");
    img.src =fetch.Img;
    let img_div = document.createElement("div");
    img_div.classList.add("col-md-4");
    img_div.appendChild(img);
    row.appendChild(img_div);

    let body_div = document.createElement("div");
    body_div.classList.add("col-md-8");

    let header = document.createElement("div");
    header.classList.add("header", "text-end");
    let btn = document.createElement("BUTTON");
    btn.classList.add("btn-close", "btn-danger");
    btn.type ="button";
    btn.setAttribute("data-bs-dismiss","toast");
    btn.setAttribute("aria-label","close");
  
    let card_body = document.createElement("div");
    card_body.classList.add("card-body");

    let h5 = create_element("h5",fetch.coursName);
    h5.classList.add("card-title", "cours_name");
    card_body.appendChild(h5);

    let level = create_element("p",fetch.level);
    level.classList.add("card-text", "level_m");
    card_body.appendChild(level);

    let dur_b=create_element("b","Տևողություն: ");
    let duration = document.createElement("p");
    duration.appendChild(dur_b);
    duration.appendChild(document.createTextNode(fetch.duration + " ամիս"));
    card_body.appendChild(duration);

    let class_b =create_element("b","Դասերի քանակ: ");
    let classes = document.createElement("p");
    classes.appendChild(class_b);
    classes.appendChild(document.createTextNode( fetch.countClass));
    card_body.appendChild(classes);

    let price =document.createElement("p");
    price.appendChild(document.createTextNode("Ամսական "));
    let span =create_element("span", fetch.price);
    span.classList.add("price");
    price.appendChild(span);
    price.appendChild(document.createTextNode(" Դր."));
    card_body.appendChild(price);

     btn.onclick = function () {removeCours(fetch.coursesId,card,h5)};
    header.appendChild(btn);

    body_div.appendChild(header);
    body_div.appendChild(card_body);
    row.appendChild(body_div);
    card.appendChild(row);
  
    document.querySelector(".offcanvas-cards").appendChild(card) ; 
}

let change = function (fetch) {
    document.querySelector('#name').value = fetch.Name;
    document.querySelector('#sname').value = fetch.Sname;
    document.querySelector('#bday').value = fetch.Bday;
    document.querySelector('#gender').value = fetch.Gender;
    document.querySelector('#userName').value = fetch.userName;
    document.querySelector('#email').value = fetch.email;

    document.querySelector('.student_img').src = 'uploads/' + fetch.Img;
    document.querySelector('#id').value = fetch.Id;
    changeModal.show();
}

let priceChenge= function(total,discount) {

    if(parseInt(discount.innerHTML) == 0){
      total.classList.remove("discount");
      discount.style.display ="none";
    }else{
      total.classList.add("discount");
      discount.style.display ="block";
    }
}
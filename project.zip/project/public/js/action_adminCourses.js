let form = document.querySelector("#formCourses");
let edit_form = document.querySelector("#editCoursesform");
let search = document.querySelector(".search");

let addModal = new bootstrap.Modal(document.getElementById('addCourses'), {
    keyboard: false
});

let editModal = new bootstrap.Modal(document.getElementById('editCourses'), {
    keyboard: false
});

form.onsubmit = function (e) {
    e.preventDefault();
    form_data = new FormData(form);
    form_data.append("level","");
 
    ajax('POST', '../post.php',form_data, form, addModal);
}
edit_form.onsubmit = function (e) {
    e.preventDefault();
    form_data = new FormData(form);
    ajax('POST', '../post.php',form_data, edit_form, editModal);
}
document.querySelector("body").onload = function (e) {
    e.preventDefault();
    form_data="";
    ajax('POST', '../post.php',form_data);
}

document.querySelector('#selectCourses').onchange = async function (e) {
    e.preventDefault();
    let searchVal = document.querySelector(".search input").value;
    let response = await fetch('../post.php?level=' + document.querySelector('.selectlevel').value + '&search='+searchVal).catch((error) => console.error(error));

    document.querySelector(".fetch").textContent = "";

        if (response.ok) {
            response.json().then(function (response) {
                let c = 0;
                if (response.fetchAllCourses) {

                    document.querySelector(".fetch").textContent = "";
                    let fetch_courses = response.fetchAllCourses;
                    let fetch_selected_courses = response.selectedCourses;
              
                    for (let i = 0; i < fetch_courses.length; i++) {
                        let fetchaCoursesArr = [];
                        for (const [key, value] of Object.entries(fetch_courses[i])) {
                            fetchaCoursesArr[`${key}`] = `${value}`;
                        }
                        let fetchSelectedArr = [];
                        for (let j = 0; j < fetch_selected_courses.length; j++) {
                            if (fetch_selected_courses[j].coursesId == fetch_courses[i].Id) {
                                fetchSelectedArr.push(fetch_selected_courses[j]);
                            }
                        }
                        c++;
                        create_tr(fetchaCoursesArr, c, fetchSelectedArr);
                    }
                    let page = response.countCoursesPage;
                    document.querySelector(".pagination").innerHTML = "";
                    document.querySelector(".pagination").appendChild(creatPagination(0, "<<"));
                    count = (page < 3) ? page : 3;

                    for (i = 1; i <= count; i++) {
                        li = creatPagination(i, i);
                        if (i == 1) {
                            li.classList.add("active");
                        }
                        li.classList.add("pages");
                        document.querySelector(".pagination").appendChild(li);
                    }

                    lastpage = page > 1 ? 2 : 0;
                    document.querySelector(".pagination").appendChild(creatPagination(lastpage, ">>"));
                }
            })
        }
}
search.onsubmit = async function (e) {
    e.preventDefault();
    let searchVal = document.querySelector(".search input").value;
    document.querySelectorAll(".table i").forEach(i => {
        if (i.classList.contains("active")) {
            i.classList.remove("active");
            if (i.classList.contains("bi-arrow-up")) {
                i.classList.remove("bi-arrow-up");
                i.classList.add("bi-arrow-down");
            }
        }
    });
    document.querySelectorAll('.selectlevel option').forEach(select => {
        select.selected = false;
        if (select.value == "Բոլորը") {
            select.selected = true;
        }
    })
        let response = await fetch('../post.php?search=' + searchVal).catch((error) => console.error(error));

        document.querySelector(".fetch").textContent = "";

        if (response.ok) {
           response.json().then(function (response) { 
            if (response.fetchAllCourses) {
               
                let fetch_courses = response.fetchAllCourses;
              
                let c = 0;
                for (let i = (fetch_courses.length-1); i >=  0 ; i--) {
                    let fetchaCoursesArr = [];
                    for (const [key, value] of Object.entries(fetch_courses[i])) {
                        fetchaCoursesArr[`${key}`] = `${value}`;
                    }
                    c++;
                   
                    create_tr(fetchaCoursesArr, c);
                }
                let page = response.countCoursesPage;
                document.querySelector(".pagination").innerHTML = "";
                document.querySelector(".pagination").appendChild(creatPagination(1, "<<"));
                count = (page < 3) ? page : 3;

                for (i = 1; i <= count; i++) {
                    li = creatPagination(i, i);
                    if (i == 1) {
                        li.classList.add("active");
                    }
                    li.classList.add("pages");
                    document.querySelector(".pagination").appendChild(li);
                }

                lastpage = page < 4 ? 3 : 4;
                document.querySelector(".pagination").appendChild(creatPagination(2, ">>"));

            } else {
                console.log("error fetch");
            }
            })
        }
}
let ajax = function (metod, src,form_data, form, modalHide) {

    let request = new XMLHttpRequest();
    request.open(metod, src);

    document.querySelector(".error").parentElement.classList.remove("show");
    document.querySelector(".error").textContent = "";
    document.querySelector(".success").parentElement.classList.remove("show");
    document.querySelector(".success").textContent = "";
    document.querySelector(".search input").value="";
    document.querySelectorAll('.selectlevel option').forEach(select => {
        select.selected = false;
        if (select.value == "Բոլորը") {
            select.selected = true;
        }
    })
    request.onreadystatechange = function () {
        
        if (request.readyState == 4 && request.status == 200) {
            let response = JSON.parse(request.responseText);
            if(response.emptyErr && response.emptyErr !="" ){
                form.classList.add("was-validated");
 
             }else if (response.error != '') { 
                alert = document.querySelector(".modalAlert");
                alert.classList.remove("alert");
                 alert.innerHTML="";
                 
                alert.innerHTML = response.error;
                alert.classList.add("alert");
               
            } else if (response.success != '') { 
                if (modalHide) {
                    modalHide.hide();
                }
                document.querySelector(".success").parentElement.classList.add("show");
                document.querySelector(".success").textContent = response.success;
            } else {
                console.log("not send");
            }
            
            if (response.fetchAllCourses !="") {
                document.querySelector(".fetch").textContent = "";

                let fetch_courses = response.fetchAllCourses;
                let c = 0;
                for (let i = (fetch_courses.length-1); i >=  0 ; i--) {
                    let fetchaCoursesArr = [];
                    for (const [key, value] of Object.entries(fetch_courses[i])) {
                        fetchaCoursesArr[`${key}`] = `${value}`;
                    }
                    c++;
                    create_tr(fetchaCoursesArr, c);
                }
                let page = response.countCoursesPage;
                document.querySelector(".pagination").innerHTML = "";
                document.querySelector(".pagination").appendChild(creatPagination(0, "<<"));
                count = (page < 3) ? page : 3;

                for (i = 1; i <= count; i++) {
                    li = creatPagination(i, i);
                    if (i == 1) {
                        li.classList.add("active");
                    }
                    li.classList.add("pages");
                    document.querySelector(".pagination").appendChild(li);
                }

                nextpage = page > 1 ? 2 : 0;
                document.querySelector(".pagination").appendChild(creatPagination(nextpage, ">>"));

            } else {
                console.log("error fetch");
            }
        }
    }

    request.send(form_data);
}

let create_tr = function (fetch, i) {

    let el_tr = document.createElement("tr");

    let del = create_button("bi-trash3-fill", "del");
    let edit = create_button("bi-pencil-fill", "edit");
    let more = create_button("bi-eye-fill", "more");
    let img = document.createElement("img");
    let td = document.createElement("td").appendChild(img);

    del.onclick = function () { delateEl(fetch.Id, el_tr) };
    edit.onclick = function () { editEl(fetch) };
    more.onclick = function () { moreEl(fetch, fetch.Id) };
    img.src = fetch.Img;

    el_tr.appendChild(create_element("th", i));
    el_tr.appendChild(td);
    el_tr.appendChild(create_element("td", fetch.coursName));
    el_tr.appendChild(create_element("td", fetch.level));
    el_tr.appendChild(create_element("td", fetch.price + " Դր․"));
    el_tr.appendChild(create_element("td", fetch.duration + " ամիս"));
    el_tr.appendChild(create_element("td", fetch.countClass));

    el_tr.appendChild(more);
    el_tr.appendChild(edit);
    el_tr.appendChild(del);
    document.querySelector(".fetch").appendChild(el_tr);
}
let create_button = function (iclass, addcllass) {
    const button = document.createElement("BUTTON");
    const i = document.createElement("i");

    button.type = "button";

    button.classList.add("btnn");
    button.classList.add("me-3");
    button.classList.add("mb-1");
    button.classList.add("" + addcllass + "");
    i.classList.add("bi");
    i.classList.add("" + iclass + "");
    button.appendChild(i);

    return button;
}
let create_element = function (element, inner) {
    const para = document.createElement("" + element + "");
    const node = document.createTextNode("" + inner + "");
    para.appendChild(node);

    return para;
}

let editEl = function (fetch) {
    document.querySelector('#editcoursName').value = fetch.coursName;
    document.querySelector('#editlevel').value = fetch.level;
    document.querySelector('#editduration').value = fetch.duration;
    document.querySelector('#editcountClass').value = fetch.countClass;
    document.querySelector('#editprice').value = fetch.price;
    document.querySelector('#editimg').value = fetch.Img;
    document.querySelector('#editCoursesId').value = fetch.Id;
    alert = create_element("div","");
    alert.classList.add("modalAlert","alert-danger","text-center");
    form = document.querySelector("#editCoursesform");
    form.insertBefore(alert, form.firstChild);
    editModal.show();
    editModal.show();
}
let moreEl =async function (fetchArr,id) {
    var more = new bootstrap.Modal(document.getElementById('moreCourses'), {
        keyboard: false
    });

    document.querySelector('#morecoursname').innerHTML = fetchArr.coursName;
    document.querySelector('#morelevel').innerHTML = fetchArr.level;
    document.querySelector('#moreduration').innerHTML = fetchArr.duration + "ամիս";
    document.querySelector('#morecount').innerHTML = fetchArr.countClass;
    document.querySelector('#moreprice').innerHTML = fetchArr.price + " Դր․";
    document.querySelector('#morecoursimg').src = fetchArr.Img;
    document.querySelector(".fetchStudents").innerHTML = "";
   
    let response = await fetch('../post.php?moreCours=' + id).catch((error) => console.error(error));
    if (response.ok) {
        response.json().then(function (fetchCourses) {
            let discountPrice=0;
            for (let i=0;i<fetchCourses.length;i++) {
              
                fetchCours =fetchCourses[i];
               
        
                let el_tr = document.createElement("tr");
               discountPrice=parseInt(fetchCours.DiscountPrice);
                    
                el_tr.appendChild(create_element("th", i+1));
                el_tr.appendChild(create_element("td", fetchCours.Name + "  " + fetchCours.Sname));
                el_tr.appendChild(create_element("td", fetchCours.email));
                el_tr.appendChild(create_element("td", fetchCours.totalPrice + " Դր․"));
                el_tr.appendChild(create_element("td", discountPrice + " Դր․"));
                document.querySelector(".fetchStudents").appendChild(el_tr);
            }
             el_tr = document.createElement("tr");
            total = fetchCourses.length *discountPrice;
            count =el_tr.appendChild(create_element("th",fetchCourses.length ));
            count.classList.add("blue");
            el_tr.appendChild(create_element("td", ""));
            el_tr.appendChild(create_element("td", ""));
            el_tr.appendChild(create_element("td", ""));
            price= el_tr.appendChild(create_element("td", total + " Դր․"));
            price.classList.add("blue");
            document.querySelector(".fetchStudents").appendChild(el_tr);

        })
    }
    more.show();
}
let delateEl = async function (id, row) {

    if (confirm("Ջնջել")) {
        row.remove();
        let response = await fetch('../post.php?deleteCours=' + id).catch((error) => console.error(error));

        document.querySelector(".error").parentElement.classList.remove("show");
        document.querySelector(".error").textContent = "";
        document.querySelector(".success").parentElement.classList.remove("show");
        document.querySelector(".success").textContent = "";

        if (response.ok) {
            response.text().then(function (text) {
                console.log(text);
                text = JSON.parse(text);
                if (text.error !== '') {
                    document.querySelector(".error").parentElement.classList.add("show");
                    document.querySelector(".error").textContent = text.error;
                } else if (text.success !== '') {
                    document.querySelector(".success").parentElement.classList.add("show");
                    document.querySelector(".success").textContent = text.success;
                }
            })
        }
    }

}
let creatPagination = function (page, inner) {
    a = create_element("a", inner);
    a.classList.add("page-link");
    a.dataset.index = page;
    li = document.createElement("li");
    li.appendChild(a);
    li.classList.add("page-item");
    if(page == 0){
        a.classList.add("disabled"); 
    }else{
        a.onclick = function () { pagination(page, this) };
    }
    return li;
}

let pagination = async function (page, a) {
    col=order="";
    document.querySelectorAll('.selectlevel option').forEach(select => {
        if (select.selected) {
            selectedLevel = select.value;
        }
    })
    document.querySelectorAll(".table i").forEach(i=>{
        if(i.classList.contains("active")){
            col=i.parentElement.dataset.index;
            if(i.classList.contains("bi-arrow-down")){//ASC
                order = "DESC ";
            }else{ //DESC
                order = "ASC";
            }
        }
    });
    let searchVal = document.querySelector(".search input").value;
    let response = await fetch('../post.php?page=' + page + '&level=' + selectedLevel+'&col=' +col +'&order=' + order+'&search='+ searchVal).catch((error) => console.error(error));

    if (response.ok) {
        document.querySelector(".fetch").textContent = "";
        response.json().then(function (response) {
            let fetch = response.fetchAllCourses;
            let c = (page - 1) * 5;
            for (let i = (fetch.length-1); i >=  0 ; i--) {
                let fetchCoursesArr = [];
                for (const [key, value] of Object.entries(fetch[i])) {
                    fetchCoursesArr[`${key}`] = `${value}`;
                }
                c++;
                create_tr(fetchCoursesArr, c);
            }
            let pageCount = response.countCoursesPage;
            document.querySelector(".pagination").innerHTML = "";

            startPage = (page - 1) == 0 ? 1 : page;
            endPage = (pageCount <= (page + 3)) ? pageCount : page + 3;
            prev = (startPage == 1) ? 0 : page - 1;
            next = (page < pageCount) ? page + 1 : 0;

            document.querySelector(".pagination").appendChild(creatPagination(prev, "<<"));
            for (i = startPage; i <= endPage; i++) {
                li = creatPagination(i, i);

                if (i == page) {
                    li.classList.add("active");
                }
                li.classList.add("pages");
                document.querySelector(".pagination").appendChild(li);
            }

            lastpage = pageCount < 4 ? 3 : 4;
            document.querySelector(".pagination").appendChild(creatPagination(next, ">>"));
        })
    }
}
document.querySelectorAll(".table i").forEach(i=>{
    i.onclick=async (e) =>{ 
        document.querySelectorAll(".table i").forEach(i=>{
            i.classList.remove("active");
        });
        col=i.parentElement.dataset.index;
        if(i.classList.contains("bi-arrow-down")){//ASC
            order = "ASC";
            i.classList.remove("bi-arrow-down","active");
            i.classList.add("bi-arrow-up","active");  
        }else{ //DESC
            order = "DESC ";
            i.classList.remove("bi-arrow-up","active");
            i.classList.add("bi-arrow-down","active");  
        }
         document.querySelectorAll('.selectlevel option').forEach(select => {
        if (select.selected) {
            selectedLevel = select.value;
        }
    })
    let searchVal = document.querySelector(".search input").value;
        page = document.querySelector(".page-item.active a").dataset.index;
        let response = await fetch('../post.php?col=' + col + '&order=' + order+'&level='+selectedLevel+'&page='+page+'&search=' + searchVal).catch((error) => console.error(error));   
        if (response.ok) {
            document.querySelector(".fetch").textContent = "";
            response.json().then(function (response) {
             
                    let fetch = response.fetchAllCourses;
                    let c = 0;
                    for (let i = (fetch.length-1); i >=  0 ; i--) {
                        let fetchCoursesArr = [];
                        for (const [key, value] of Object.entries(fetch[i])) {
                            fetchCoursesArr[`${key}`] = `${value}`;
                        }
                        c++;
                        create_tr(fetchCoursesArr, c );
                    }
            })
        }
    }
})
document.querySelector(".add").addEventListener("click", () => {
    addModal.show();
    alert = create_element("div","");
    alert.classList.add("modalAlert","alert-danger","text-center");
    form = document.querySelector("#formCourses");
    form.insertBefore(alert, form.firstChild);
})

document.getElementById('addCourses').addEventListener('hidden.bs.modal', event => {
    form = document.querySelector("#formCourses");
    form.reset();
    form.classList.remove("was-validated");
    form.removeChild(form.firstChild);
});
document.getElementById('editCourses').addEventListener('hidden.bs.modal', event => {
    form = document.querySelector("#editCoursesform");
    form.reset();
    form.classList.remove("was-validated");
    form.removeChild(form.firstChild);
})
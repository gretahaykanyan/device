let form = document.querySelector("#form");
let edit_form = document.querySelector("#editform");
let search = document.querySelector(".search");
let addModal = new bootstrap.Modal(document.getElementById('add'), {
    keyboard: false
});
let editModal = new bootstrap.Modal(document.getElementById('edit'), {
    keyboard: false
});

form.onsubmit = function (e) {
    e.preventDefault();
    form_data = new FormData(form);
    form_data.append("Gender", "");

    ajax('POST', '../post.php', form_data, form, addModal);
}
edit_form.onsubmit = function (e) {
    e.preventDefault();

    form_data = new FormData(form);

    ajax('POST', '../post.php', form_data, edit_form, editModal);
}
document.querySelector("body").onload = function (e) {
    console.log(window.location);
    e.preventDefault();
    if (window.location.hash != "") {
        get = decodeURIComponent(window.location.hash).substring(1);
        console.log(get);
        let response = fetch('../post.php?' + get).then(
            (res => {
                if (res.ok) {
                    res.json().then(function (response) {
                        let hrefArr = new Array();
                     
                        get.split("&").forEach(value => {
                            value = value.split("=");
                            key = value[0];
                            hrefArr[key] = value[1];
                        })
                        console.log(hrefArr);
                        link(response,hrefArr);
                    });
                }
            })
        )
            .catch((error) => console.error(error));
    } else {
        form_data = "";
        ajax('POST', '../post.php', form_data);
    }
}

document.querySelector('#selectform').onchange = async function (e) {

    e.preventDefault();
    let searchVal = document.querySelector(".search input").value;
    window.location.hash = encodeURIComponent('gender=' + document.querySelector('.select').value + '&search=' + searchVal);
    let response = await fetch('../post.php?gender=' + document.querySelector('.select').value + '&search=' + searchVal).catch((error) => console.error(error));

    document.querySelector(".fetch").textContent = "";

    if (response.ok) {
        response.json().then(function (response) {
            if (response.fetchStudents) {
                let fetch = response.fetchStudents;
                let fetchCourses = response.selectedCourses;

                let c = 0;
                for (let i = (fetch.length - 1); i >= 0; i--) {
                    let fetchStudentsArr = [];
                    for (const [key, value] of Object.entries(fetch[i])) {
                        fetchStudentsArr[`${key}`] = `${value}`;
                    }

                    let fetchCoursesArr = [];
                    for (let j = 0; j < fetchCourses.length; j++) {
                        if (fetchCourses[j].Id == fetch[i].Id) {
                            fetchCoursesArr.push(fetchCourses[j]);
                        }
                    }
                    c++;

                    create_tr(fetchStudentsArr, c, fetchCoursesArr);
                }
                let page = response.countStudentsPage;
                document.querySelector(".pagination").innerHTML = "";
                document.querySelector(".pagination").appendChild(creatPagination(0, "<<"));

                count = (page < 3) ? page : 3;
                for (i = 1; i <= count; i++) {

                    li = creatPagination(i, i);

                    if (i == 1) {
                        li.classList.add("active");
                    }
                    li.classList.add("pages");
                    document.querySelector(".pagination").appendChild(li);
                }

                nextpage = page > 1 ? 2 : 0;
                document.querySelector(".pagination").appendChild(creatPagination(nextpage, ">>"));
            } else {
                console.log("error fetch");
            }
        })
    }
}
search.onsubmit = async function (e) {
    e.preventDefault();
    let searchVal = document.querySelector(".search input").value;
    document.querySelectorAll(".table i").forEach(i => {
        if (i.classList.contains("active")) {
            i.classList.remove("active");
            if (i.classList.contains("bi-arrow-up")) {
                i.classList.remove("bi-arrow-up");
                i.classList.add("bi-arrow-down");
            }
        }
    });
    document.querySelectorAll('.select option').forEach(select => {
        select.selected = false;
        if (select.value == "Բոլորը") {
            select.selected = true;
        }
    })
    window.location.hash = encodeURIComponent('search=' + searchVal);
    let response = await fetch('../post.php?search=' + searchVal).catch((error) => console.error(error));
    document.querySelector(".fetch").textContent = "";

    if (response.ok) {
        response.json().then(function (response) {
            if (response.fetchStudents) {
                let fetch = response.fetchStudents;
                let fetchCourses = response.selectedCourses;;
                let c = 0;
                for (let i = (fetch.length - 1); i >= 0; i--) {
                    let fetchStudentsArr = [];
                    for (const [key, value] of Object.entries(fetch[i])) {
                        fetchStudentsArr[`${key}`] = `${value}`;
                    }
                    let fetchCoursesArr = [];
                    for (let j = 0; j < fetchCourses.length; j++) {
                        if (fetchCourses[j].Id == fetch[i].Id) {

                            fetchCoursesArr.push(fetchCourses[j]);
                        }
                    }
                    c++;
                    create_tr(fetchStudentsArr, c, fetchCoursesArr);

                }
                let page = response.countStudentsPage;
                document.querySelector(".pagination").innerHTML = "";
                document.querySelector(".pagination").appendChild(creatPagination(1, "<<"));
                count = (page < 3) ? page : 3;

                for (i = 1; i <= count; i++) {
                    li = creatPagination(i, i);
                    if (i == 1) {
                        li.classList.add("active");
                    }
                    li.classList.add("pages");
                    document.querySelector(".pagination").appendChild(li);
                }
                lastpage = page < 4 ? 3 : 4;
                document.querySelector(".pagination").appendChild(creatPagination(2, ">>"));

            } else {
                console.log("error fetch");
            }
        })
    }
}
let ajax = async function (metod, src, form_data, form, modalHide) {

    // let request = new XMLHttpRequest();

    //  request.open(metod, src);
    let response = await fetch(src, {
        method: metod,
        body: form_data,
        referrerPolicy: "unsafe-url",
        // ...
    });
    document.querySelector(".error").parentElement.classList.remove("show");
    document.querySelector(".error").textContent = "";
    document.querySelector(".success").parentElement.classList.remove("show");
    document.querySelector(".success").textContent = "";

    document.querySelector(".search input").value = "";
    document.querySelectorAll('.select option').forEach(select => {
        select.selected = false;
        if (select.value == "Բոլորը") {
            select.selected = true;
        }
    })
    console.log(response);
    //request.onreadystatechange = function () {

    // if (request.readyState == 4 && request.status == 200) {
    //     let response = JSON.parse(request.responseText);
    if (response.ok) {
        response.json().then(function (response) {

            if (response.emptyErr && response.emptyErr != "") {
                form.classList.add("was-validated");

            } else if (response.error != '') {
                alert = document.querySelector(".modalAlert");
                alert.classList.remove("alert");
                alert.innerHTML = "";

                alert.innerHTML = response.error;
                alert.classList.add("alert");

            } else if (response.success != '') {
                if (modalHide) {
                    modalHide.hide();
                }
                document.querySelector(".success").parentElement.classList.add("show");
                document.querySelector(".success").textContent = response.success;
            } else {
                console.log("not send");
            }

            if (response.fetchStudents != "") {
                document.querySelector(".fetch").textContent = "";
                let fetch = response.fetchStudents;
                let fetchCourses = response.selectedCourses;;
                let c = 0;
                for (let i = (fetch.length - 1); i >= 0; i--) {
                    let fetchStudentsArr = [];
                    for (const [key, value] of Object.entries(fetch[i])) {
                        fetchStudentsArr[`${key}`] = `${value}`;
                    }
                    let fetchCoursesArr = [];
                    for (let j = 0; j < fetchCourses.length; j++) {
                        if (fetchCourses[j].Id == fetch[i].Id) {

                            fetchCoursesArr.push(fetchCourses[j]);
                        }
                    }
                    c++;
                    create_tr(fetchStudentsArr, c, fetchCoursesArr);
                }
                let page = response.countStudentsPage;
                document.querySelector(".pagination").innerHTML = "";
                document.querySelector(".pagination").appendChild(creatPagination(0, "<<"));
                count = (page < 3) ? page : 3;

                for (i = 1; i <= count; i++) {
                    li = creatPagination(i, i);
                    if (i == 1) {
                        li.classList.add("active");
                    }
                    li.classList.add("pages");
                    document.querySelector(".pagination").appendChild(li);
                }
                nextpage = page > 1 ? 2 : 0;
                document.querySelector(".pagination").appendChild(creatPagination(nextpage, ">>"));

            } else {
                console.log("error fetch");
            }

        })
    }

    // request.send(form_data);
}

let create_button = function (iclass, addcllass) {
    const button = document.createElement("BUTTON");
    const i = document.createElement("i");

    button.type = "button";

    button.classList.add("btnn");
    button.classList.add("me-3");
    button.classList.add("mb-1");
    button.classList.add("" + addcllass + "");
    i.classList.add("bi");
    i.classList.add("" + iclass + "");
    button.appendChild(i);

    return button;
}
let create_element = function (element, inner) {
    const para = document.createElement("" + element + "");
    const node = document.createTextNode("" + inner + "");
    para.appendChild(node);

    return para;
}

let editEl = function (fetch) {

    document.querySelector('#editname').value = fetch.Name;
    document.querySelector('#editsname').value = fetch.Sname;
    document.querySelector('#editbday').value = fetch.Bday;
    document.querySelector('#editgender').value = fetch.Gender;
    //document.querySelector('#editimg').src = 'uploads/'+fetch.Img;
    document.querySelector('#editid').value = fetch.Id;
    alert = create_element("div", "");
    alert.classList.add("modalAlert", "alert-danger", "text-center");
    form = document.querySelector("#editform");
    form.insertBefore(alert, form.firstChild);
    editModal.show();
}
let moreEl = function (fetch, fetchCourses) {
    var more = new bootstrap.Modal(document.getElementById('more'), {
        keyboard: false
    });

    document.querySelector('#morename').innerHTML = fetch.Name;
    document.querySelector('#moresname').innerHTML = fetch.Sname;
    document.querySelector('#morebday').innerHTML = fetch.Bday;
    document.querySelector('#moregender').innerHTML = fetch.Gender;
    document.querySelector('#moreemail').innerHTML = fetch.email;
    document.querySelector('#moreuname').innerHTML = fetch.userName;
    document.querySelector('#moreimg').src = '../uploads/' + fetch.Img;
    document.querySelector(".fetchCourses").innerHTML = "";
    let i = 0;
    for (fetchCours of fetchCourses) {
        i++;

        let el_tr = document.createElement("tr");
       /* if(fetchCours.DiscountPrice == 0){
            discountPrice =fetch.totalPrice;
        }else{
            ;
        }*/discountPrice = parseInt(fetchCours.DiscountPrice);
        el_tr.appendChild(create_element("th", i));
        el_tr.appendChild(create_element("td", fetchCours.coursName + "  \n" + fetchCours.level));
        el_tr.appendChild(create_element("td", fetchCours.duration + "  ամիս"));
        el_tr.appendChild(create_element("td", fetchCours.price + " Դր․"));
        el_tr.appendChild(create_element("td", fetchCours.totalPrice + " Դր․"));
        el_tr.appendChild(create_element("td", discountPrice + " Դր․"));
        document.querySelector(".fetchCourses").appendChild(el_tr);
    }
    let el_tr = document.createElement("tr");
    el_tr.appendChild(create_element("td", ""));
    el_tr.appendChild(create_element("td", ""));
    el_tr.appendChild(create_element("td", ""));
    el_tr.appendChild(create_element("td", ""));
    el_tr.appendChild(create_element("td", fetch.totalPrice + " Դր․"));
       /* if(fetch.DiscountPrice == 0){
            discountPrice =fetch.totalPrice;
        }else{
            
        }*/discountPrice = parseInt(fetch.DiscountPrice);
    let price = create_element("td", parseInt(discountPrice) + " Դր․");
    price.classList.add("blue");
    el_tr.appendChild(price);
    document.querySelector(".fetchCourses").appendChild(el_tr);
    more.show();
}
let create_tr = function (fetch, i, fetchCourses) {
    let src = '../uploads/';
    let el_tr = document.createElement("tr");

    let del = create_button("bi-trash3-fill", "del");
    let edit = create_button("bi-pencil-fill", "edit");
    let more = create_button("bi-eye-fill", "more");
    let img = document.createElement("img");
    let td = document.createElement("td").appendChild(img);


    del.onclick = function () { delateEl(fetch.Id, el_tr) };
    edit.onclick = function () { editEl(fetch) };
    more.onclick = function () { moreEl(fetch, fetchCourses) };
    img.src = src + fetch.Img;

    el_tr.appendChild(create_element("th", i));
    el_tr.appendChild(td);
    el_tr.appendChild(create_element("td", fetch.Name));
    el_tr.appendChild(create_element("td", fetch.Sname));
    el_tr.appendChild(create_element("td", fetch.Bday));
    el_tr.appendChild(create_element("td", fetch.Gender));
    el_tr.appendChild(create_element("td", fetch.totalPrice + " Դր․"));
    el_tr.appendChild(create_element("td", parseInt(fetch.DiscountPrice) + " Դր․"));
    el_tr.appendChild(more);
    el_tr.appendChild(edit);
    el_tr.appendChild(del);
    document.querySelector(".fetch").appendChild(el_tr);



}

let delateEl = async function (id, row) {

    if (confirm("Ջնջել")) {
        row.remove();
        let response = await fetch('../post.php?delete=' + id).catch((error) => console.error(error));

        document.querySelector(".error").parentElement.classList.remove("show");
        document.querySelector(".error").textContent = "";
        document.querySelector(".success").parentElement.classList.remove("show");
        document.querySelector(".success").textContent = "";

        if (response.ok) {
            response.text().then(function (text) {
                console.log(text);
                text = JSON.parse(text);
                if (text.error !== '') {
                    document.querySelector(".error").parentElement.classList.add("show");
                    document.querySelector(".error").textContent = text.error;
                } else if (text.success !== '') {
                    document.querySelector(".success").parentElement.classList.add("show");
                    document.querySelector(".success").textContent = text.success;
                }
                /*let fetch =text.fetch;  
                   
                    for(let i=0; i < fetch.length;i++){
                        let fetchArr =[];
                        for( const [key,value] of Object.entries(fetch[i])){
                            fetchArr[`${key}`]=  `${value}`;
                        }
                        create_tr(fetchArr,i);
                 }*/

            })
        }
    }

}
let creatPagination = function (page, inner) {
    a = create_element("a", inner);
    a.classList.add("page-link");
    a.dataset.index = page;
    li = document.createElement("li");
    li.appendChild(a);
    li.classList.add("page-item");
    if (page == 0) {
        a.classList.add("disabled");
    } else {
        a.onclick = function () { pagination(page, this) };
    }
    return li;
}

let pagination = async function (page, a) {
    col = "";
    order = "";

    // if(selectedGender == ""){
    document.querySelectorAll('.select option').forEach(select => {
        if (select.selected) {
            selectedGender = select.value;
        }
    })
    //}
    document.querySelectorAll(".table i").forEach(i => {
        if (i.classList.contains("active")) {
            col = i.parentElement.dataset.index;
            if (i.classList.contains("bi-arrow-down")) {//ASC
                order = "DESC ";
            } else { //DESC
                order = "ASC";
            }
        }
    });
    let searchVal = document.querySelector(".search input").value;
    window.location.hash = encodeURIComponent('page=' + page + '&gender=' + selectedGender + '&col=' + col + '&order=' + order + '&search=' + searchVal);
    // get = window.location.hash.substr(1);
    let response = await fetch('../post.php?page=' + page + '&gender=' + selectedGender + '&col=' + col + '&order=' + order + '&search=' + searchVal).catch((error) => console.error(error));
    
    if (response.ok) {
        document.querySelector(".fetch").textContent = "";
        response.json().then(function (response) {
            let fetch = response.fetchStudents;
            let fetchCourses = response.selectedCourses;
            let c = (page - 1) * 5;
            for (let i = (fetch.length - 1); i >= 0; i--) {
                let fetchStudentsArr = [];
                for (const [key, value] of Object.entries(fetch[i])) {
                    fetchStudentsArr[`${key}`] = `${value}`;
                }
                let fetchCoursesArr = [];
                for (let j = 0; j < fetchCourses.length; j++) {
                    if (fetchCourses[j].Id == fetch[i].Id) {

                        fetchCoursesArr.push(fetchCourses[j]);

                    }
                }
                c++;
                create_tr(fetchStudentsArr, c, fetchCoursesArr);
            }
            let pageCount = response.countStudentsPage;
            document.querySelector(".pagination").innerHTML = "";

            startPage = (page - 1) == 0 ? 1 : page;
            endPage = (pageCount <= (page + 3)) ? pageCount : page + 3;
            prev = (startPage == 1) ? 0 : page - 1;
            next = (page < pageCount) ? page + 1 : 0;

            document.querySelector(".pagination").appendChild(creatPagination(prev, "<<"));
            for (i = startPage; i <= endPage; i++) {

                li = creatPagination(i, i);

                if (i == page) {
                    li.classList.add("active");
                }
                li.classList.add("pages");
                document.querySelector(".pagination").appendChild(li);
            }

            lastpage = pageCount < 4 ? 3 : 4;
            document.querySelector(".pagination").appendChild(creatPagination(next, ">>"));
        })
    }
}

link = function (response,arr) {
    page = parseInt(arr.page);
    gender = arr.gender;
    col = arr.col;
    order = arr.order;
    search = arr.search;console.log(search);

    document.querySelector(".search input").value = search;
    document.querySelectorAll('.select option').forEach(select => {
        if (select.value == gender) {
            select.selected = true;
        }
    })
    //if(col != "" && order != ""){
        document.querySelectorAll(".table i").forEach(i => {
         
           
            if ( i.offsetParent.dataset.index == col) {
               i.classList.add("active");
                if (order == "DESC ") {
                    i.classList.remove("bi-arrow-up");
                    i.classList.add("bi-arrow-down");
                } else { 
                    i.classList.remove("bi-arrow-down");
                    i.classList.add("bi-arrow-up");
                }
            }
        });
   // }

    if (response.fetchStudents) {
        let fetch = response.fetchStudents;
        let fetchCourses = response.selectedCourses;

        let c = (page - 1) * 5;
        for (let i = (fetch.length - 1); i >= 0; i--) {
            let fetchStudentsArr = [];
            for (const [key, value] of Object.entries(fetch[i])) {
                fetchStudentsArr[`${key}`] = `${value}`;
            }

            let fetchCoursesArr = [];
            for (let j = 0; j < fetchCourses.length; j++) {
                if (fetchCourses[j].Id == fetch[i].Id) {
                    fetchCoursesArr.push(fetchCourses[j]);
                }
            }
            c++;

            create_tr(fetchStudentsArr, c, fetchCoursesArr);
        }
       
        let pageCount = response.countStudentsPage;
        document.querySelector(".pagination").innerHTML = "";

        startPage = (page - 1) == 0 ? 1 : page;
        endPage = (pageCount <= (page + 3)) ? pageCount : page + 3;
        prev = (startPage == 1) ? 0 : page - 1;
        next = (page < pageCount) ? page + 1 : 0;

        document.querySelector(".pagination").appendChild(creatPagination(prev, "<<"));
        for (i = startPage; i <= endPage; i++) {

            li = creatPagination(i, i);

            if (i == page) {
                li.classList.add("active");
            }
            li.classList.add("pages");
            document.querySelector(".pagination").appendChild(li);
        }

        lastpage = pageCount < 4 ? 3 : 4;
        document.querySelector(".pagination").appendChild(creatPagination(next, ">>"));
    }
}
document.querySelectorAll(".table i").forEach(i => {
    i.onclick = async (e) => {
        document.querySelectorAll(".table i").forEach(ii => {
            ii.classList.remove("active");
            if (ii.offsetParent.dataset.index != i.offsetParent.dataset.index) {
                ii.classList.remove("bi-arrow-up");
                ii.classList.add("bi-arrow-down");
            }
        });
        col = i.parentElement.dataset.index;
        if (i.classList.contains("bi-arrow-down")) {//ASC
            order = "ASC";
            i.classList.remove("bi-arrow-down", "active");
            i.classList.add("bi-arrow-up", "active");

        } else { //DESC
            order = "DESC ";
            i.classList.remove("bi-arrow-up", "active");
            i.classList.add("bi-arrow-down", "active");

        }
        document.querySelectorAll('.select option').forEach(select => {
            if (select.selected) {
                selectedGender = select.value;
            }
        })
        let searchVal = document.querySelector(".search input").value;
        page = document.querySelector(".page-item.active a").dataset.index;

        window.location.hash = encodeURIComponent('page=' + page + '&gender=' + selectedGender + '&col=' + col + '&order=' + order + '&search=' + searchVal);
        let response = await fetch('../post.php?col=' + col + '&order=' + order + '&gender=' + selectedGender + '&page=' + page + '&search=' + searchVal).catch((error) => console.error(error));
        if (response.ok) {
            document.querySelector(".fetch").textContent = "";
            response.json().then(function (response) {

                let fetch = response.fetchStudents;
                let fetchCourses = response.selectedCourses;;
                let c = (page - 1) * 5;
                for (let i = (fetch.length - 1); i >= 0; i--) {
                    let fetchStudentsArr = [];
                    for (const [key, value] of Object.entries(fetch[i])) {
                        fetchStudentsArr[`${key}`] = `${value}`;
                    }
                    let fetchCoursesArr = [];
                    for (let j = 0; j < fetchCourses.length; j++) {
                        if (fetchCourses[j].Id == fetch[i].Id) {

                            fetchCoursesArr.push(fetchCourses[j]);
                        }
                    }
                    c++;
                    create_tr(fetchStudentsArr, c, fetchCoursesArr);
                }
            })
        }
    }
})
document.querySelector(".add").addEventListener("click", () => {
    addModal.show();
    alert = create_element("div", "");
    alert.classList.add("modalAlert", "alert-danger", "text-center");
    form = document.querySelector("#form");
    form.insertBefore(alert, form.firstChild);
})
document.getElementById('add').addEventListener('hidden.bs.modal', event => {
    form = document.querySelector("#form");
    form.reset();
    form.classList.remove("was-validated");
    form.removeChild(form.firstChild);
});
document.getElementById('edit').addEventListener('hidden.bs.modal', event => {
    form = document.querySelector("#editform");
    form.reset();
    form.classList.remove("was-validated");
    form.removeChild(form.firstChild);
})

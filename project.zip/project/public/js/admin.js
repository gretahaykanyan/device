
(function () {
  'use strict'
  var forms = document.querySelectorAll('.needs-validation')

  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }
        form.classList.add('was-validated')
      }, false)
    })
})();
document.querySelectorAll(".input-field input[type=file]").forEach(img=>{
  img.onclick = () => {
      img.required = true;
        img.classList.add("form-control");
        
}
});

const toastLiveExample = document.getElementById('liveToast2');
const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
const toastLiveExample1 = document.getElementById('liveToast1');
const toastBootstrap1 = bootstrap.Toast.getOrCreateInstance(toastLiveExample1);
const toastLiveExample2 = document.getElementById('liveToast3');
const toastBootstrap2 = bootstrap.Toast.getOrCreateInstance(toastLiveExample2);




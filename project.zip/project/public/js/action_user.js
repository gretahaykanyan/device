
let form = document.querySelector("#form");
form.onsubmit = function (e){
    e.preventDefault();

	let form_data =new FormData(form) ;

	let request = new XMLHttpRequest();
   document.querySelector(".loading").classList.add("sending");
	request.open('POST', '../post.php');

    document.querySelector(".response_error").parentElement.classList.remove("alert");
    document.querySelector(".response_error").textContent="";
    document.querySelector(".response_success").parentElement.classList.remove("alert");
    document.querySelector(".response_success").textContent="";

	request.onreadystatechange = function()
	{
         
		if(request.readyState == 4 && request.status == 200)
		{   
            let response = JSON. parse( request.responseText );
          
            if(!response.ok){
                if(response.error != '')
                {
                    document.querySelector(".response_error").parentElement.classList.add("alert");
                    document.querySelector(".response_error").textContent= response.error;

                }else if(response.success != '')
                {
                    document.querySelector(".response_success").parentElement.classList.add("alert");
                    document.querySelector(".response_success").textContent= response.success;
                   
                }else{
                    console.log("not send") ;
                }
            }else{
                location.href = '../'+response.success;
               
            }
		}
        document.querySelector(".loading").classList.remove("sending");
	}
    request.send(form_data);
    
	
}

/*range price*/ 
const rangeInput = document.querySelectorAll(".range-input input"),
  priceInput = document.querySelectorAll(".price-input input"),
  range = document.querySelector(".slider .progress");
let priceGap = 1000;

priceInput.forEach((input) => {
  input.addEventListener("input", (e) => {
    let minPrice = parseInt(priceInput[0].value),
      maxPrice = parseInt(priceInput[1].value);

    if (maxPrice - minPrice >= priceGap && maxPrice <= rangeInput[1].max) {
      if (e.target.className === "input-min") {
        rangeInput[0].value = minPrice;
        range.style.left = (minPrice / rangeInput[0].max) * 100 + "%";
      } else {
        rangeInput[1].value = maxPrice;
        range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
      }
    }
  });
});

rangeInput.forEach((input) => {
  input.addEventListener("input", (e) => {
    let minVal = parseInt(rangeInput[0].value),
      maxVal = parseInt(rangeInput[1].value);

    if (maxVal - minVal < priceGap) {
      if (e.target.className === "range-min") {
        rangeInput[0].value = maxVal - priceGap;
      } else {
        rangeInput[1].value = minVal + priceGap;
      }
    } else {
      priceInput[0].value = minVal;
      priceInput[1].value = maxVal;
      range.style.left = (minVal / rangeInput[0].max) * 100 + "%";
      range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
    }
  });
});

/*filtration*/ 
let checkboxs =document.querySelectorAll(".filter input");
let checkbox_courses =document.querySelectorAll(".courses .form-check-input");
let checkbox_level =document.querySelectorAll(".level .form-check-input");
let  cardsListNew =[];

function Filter(checkboxs,items){
    checkboxs.forEach(function(checkbox){
       
        if(checkbox.checked == true){  
            items.forEach(function(item){
                let cardd= item.parentElement;
                if (item.innerHTML.includes(checkbox.value)) {
                    cardd.parentElement.classList.remove("none");
                   
                }
            })
        }else{
            items.forEach(function(item){   debugger;
                let cardd= item.parentElement;
                if (item.innerHTML.includes(checkbox.value)) {
                    cardd.parentElement.classList.add("none");
                }
            })
        }
    })
} 
function rangePrice(){
 let cardsContainer = document.querySelector('.courses_cards');
   let cards =cardsContainer.querySelectorAll(":scope card-body");
   let range_min =document.querySelector(".input-min").value;
   let range_max =document.querySelector(".input-max").value;
   let priceList = document.querySelectorAll(".priceCard");
   cards.forEach(function(card){card.parentElement.classList.remove("none"); })
   cardsListNew= [];
    priceList.forEach(function(price){
      let card =price.parentElement.parentElement.parentElement;
      
        if( ((Number(range_min) <= (parseFloat(price.innerHTML))) &&((parseFloat(price.innerHTML))<= Number(range_max))  )== false) { 
          card.classList.add("none");
        }else{
          cardsListNew.push(price.parentElement.parentElement);
          
        } 
    }) 

}

checkboxs.forEach(function(checkbox){
    checkbox.addEventListener("change",function(){
        
        let levelList =[]; cardsListNew =[];
        let ccount = 0;let lcount = 0;
        checkbox_courses.forEach(function (courses){ if(courses.checked == true){ccount++}});
        checkbox_level.forEach(function (level){ if(level.checked == true){lcount++}});
     
      
        rangePrice();
        let cardList =[];
      
        cardsListNew.forEach(function(cards){
          
            let h5 =cards.childNodes[0];
            // console.log(h5);
            cardList.push(h5) ;
        });
        
        if( ccount > 0){
            
            Filter(checkbox_courses,cardList);
            cardList = cardList.filter(elm => elm);
           
            
            if( lcount > 0){ 
                cardList.forEach(function (h5,index){ 
                    let card_body = h5.parentElement;
                    if(!(card_body.parentElement.classList.contains("none"))){ 
                      levelList.push(card_body.children[1]);
                    }
                });
                Filter(checkbox_level,levelList);
                
            }
        }else if( lcount > 0){
          
          cardList.forEach(function (h5,index){ 
            let card_body = h5.parentElement;
            
              levelList.push(card_body.children[1]);
            
          });
          Filter(checkbox_level,levelList);
            
        }else{
          
           cardsListNew.forEach(function(card){
                card.parentElement.classList.remove("none");
            })
        }
    })
})


function confirm_remAll(id){
    if(confirm("Ջնջել բոլորը")){
      window.location.href = "index.php?remAll="+id;
    }
}
const toastLiveExample = document.getElementById('liveToast2');
const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
const toastLiveExample1 = document.getElementById('liveToast1');
const toastBootstrap1 = bootstrap.Toast.getOrCreateInstance(toastLiveExample1);
const toastLiveExample2 = document.getElementById('liveToast3');
const toastBootstrap2 = bootstrap.Toast.getOrCreateInstance(toastLiveExample2);



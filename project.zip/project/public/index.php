<?php
session_start();
require __DIR__ . "/../autoload.php";
$url=new Url();


if(isset($_GET['email']) && $_GET['code']){
    $user = new \model\Users();
    $user->verified($_GET['email'],$_GET['code']);
} 
if(isset($_GET['logout']) ){
	echo
	"<script>
		document.querySelector('.loading').classList.add('sending');
	</script>";
	unset($_SESSION["uname"]);
	echo"
	<script>
		window.location.reload()
	</script>
	";
	
}

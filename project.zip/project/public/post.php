<?php
session_start();
require __DIR__ . "/../autoload.php";
  
if($_SESSION['page'] == "admin"){

    $admin = new controller\Admin;
    if($_SESSION['pagination'] == "courses"){
        $admin->coursesData();
    }else{
        $admin->studentsData();
    }
   
}else if($_SESSION['page'] == "students"){

    $student = new controller\Students;
    $student->index(); 

}else if($_SESSION['page'] == "users"){
    
    $users = new controller\Users;
    $users->index();
}